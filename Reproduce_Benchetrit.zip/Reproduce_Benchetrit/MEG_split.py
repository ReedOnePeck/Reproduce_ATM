import os
import mne
import numpy as np
import pickle
import glob
from collections import Counter
import shutil
from tqdm import tqdm

def save_data(data, output_file):
    with open(output_file, 'wb') as file:
        pickle.dump(data, file, protocol=4)

fif_file = "/nfs/nica-datashop/Things-data/Things-MEG_lyz/preprocessed_P1-epo.fif"
output_dir = "/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy"
def read_and_crop_epochs(fif_file):
    epochs = mne.read_epochs(fif_file, preload=True)
    cropped_epochs = epochs.crop(tmin=0, tmax=1.0)
    return cropped_epochs

epochs = read_and_crop_epochs(fif_file)
sorted_indices = np.argsort(epochs.events[:, 2])
epochs = epochs[sorted_indices]
print("===========================================================================================")
print("len(epochs.events)",len(epochs.events))

import pandas as pd
csv_file_path = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/image_concept_index.csv'
image_concept_df = pd.read_csv(csv_file_path, header=None)
print("===========================================================================================")
print("image_concept_df",image_concept_df)

def filter_valid_epochs(epochs, exclude_event_id=999999):
    return epochs[epochs.events[:, 2] != exclude_event_id]

valid_epochs = filter_valid_epochs(epochs)
print("===========================================================================================")
print("valid_epochs.info",valid_epochs.info)
print("valid_epochs.events.shape",valid_epochs.events.shape)

def identify_zs_event_ids(epochs, num_repetitions=12):
    event_ids = epochs.events[:, 2]
    unique_event_ids, counts = np.unique(event_ids, return_counts=True)
    zs_event_ids = unique_event_ids[counts == num_repetitions]
    return zs_event_ids

zs_event_ids = identify_zs_event_ids(valid_epochs)
# Verify the zero-shot event IDs
print("===========================================================================================")
print("lenth of Zero-shot Event IDs:", len(zs_event_ids))
print("Zero-shot Event IDs:", zs_event_ids)


training_epochs = valid_epochs[~np.isin(valid_epochs.events[:, 2], zs_event_ids)]
# Verify the number of events in the training set
print("===========================================================================================")
print("Number of events in the training set:", len(training_epochs.events))
print(len(training_epochs.events))

# Extract event IDs from the filtered training epochs
training_event_ids = np.unique(training_epochs.events[:, 2])

# Check for any overlap between zero-shot and training event IDs
overlap_ids = np.intersect1d(zs_event_ids, training_event_ids)

# Print the overlap, if any
print("===========================================================================================")
print("Overlapping Event IDs:", overlap_ids)


zs_test_epochs = valid_epochs[np.isin(valid_epochs.events[:, 2], zs_event_ids)]
print("===========================================================================================")
print(len(training_epochs.events))
print(len(zs_test_epochs.events))

print(training_epochs.events[:, -1])
print(zs_test_epochs.events[:, -1])

training_event_ids = training_epochs.events[:, -1]
test_event_ids = zs_test_epochs.events[:, -1]

counts = {test_id: np.sum(training_event_ids == test_id) for test_id in test_event_ids}

zs_event_to_category_map = {}

for i, event_id in enumerate(zs_event_ids):
    # Using the row index (i) to map to the image category index
    # Assuming the first event_id corresponds to the first row, second event_id to the second row, and so on
    image_category_index = image_concept_df.iloc[event_id-1, 0]  # Accessing the first (and only) column at row i
    zs_event_to_category_map[event_id] = image_category_index

# Print the mapping
print("Event ID to Image Category Index Mapping:")
for event_id, category_index in zs_event_to_category_map.items():
    print(f"Event ID {event_id}: Image Category Index {category_index}")

# List to hold all the categories in the test set
test_set_categories = []

# Iterate over the event IDs in the test set
for event_id in zs_event_ids:
    if event_id in zs_event_to_category_map:
        # Get the category index from the mapping
        category_index = zs_event_to_category_map[event_id]
        test_set_categories.append(category_index)

# Print the list of categories in the test set
print("Categories in the test set:", test_set_categories)
print("length of Categories in the test set:",len(test_set_categories))


# Count the occurrences of each category ID in the training set
category_counts = Counter(test_set_categories)

# Print the counts of each category ID
print("Counts of each category ID in the training set:")
for category_id, count in category_counts.items():
    print(f"Category ID {category_id}: Count {count}")

event_to_category_map = {}

for i, event_id in enumerate(training_event_ids):
    # Using the row index (i) to map to the image category index
    # Assuming the first event_id corresponds to the first row, second event_id to the second row, and so on
    image_category_index = image_concept_df.iloc[event_id-1, 0]  # Accessing the first (and only) column at row i
    event_to_category_map[event_id] = image_category_index

# Print the mapping
print("Event ID to Image Category Index Mapping:")
for event_id, category_index in event_to_category_map.items():
    print(f"Event ID {event_id}: Image Category Index {category_index}")


# Assuming training_epochs is a variable that contains your training set epochs
# And it has an 'events' attribute similar to zs_test_epochs

# List to hold all the categories in the training set
train_set_categories = []

# Extract event IDs from the training set
training_event_ids = training_epochs.events[:, 2]

# Iterate over the event IDs in the training set
for event_id in training_event_ids:
    if event_id in event_to_category_map:
        # Get the category index from the mapping
        category_index = event_to_category_map[event_id]
        train_set_categories.append(category_index)

# Print the list of categories in the training set
print("Categories in the training set:", train_set_categories)
print("Total number of category entries in the training set:", len(train_set_categories))

# Count the occurrences of each category ID in the training set
category_counts = Counter(train_set_categories)

# Print the counts of each category ID
print("Counts of each category ID in the training set:")
for category_id, count in category_counts.items():
    print(f"Category ID {category_id}: Count {count}")

counts = {test_id: np.sum(train_set_categories == test_id) for test_id in test_set_categories}
# Calculate the total number of elements in 'counts'
total_elements = sum(counts.values())

# Print the total number of elements
print("Total number of elements represented in 'counts':", total_elements)


train_set_categories_filtered = [item for item in train_set_categories if item not in test_set_categories]

# train_set_categories_filtered now contains elements from train_set_categories excluding those in test_set_categories
print("Filtered train_set_categories:", train_set_categories_filtered)

# Create a mask for epochs to keep in the training set
keep_epochs_mask = [category not in test_set_categories for category in train_set_categories]

# Apply the mask to filter out epochs from training_epochs
training_epochs_filtered = training_epochs[keep_epochs_mask]

# Confirm the filtering
print("Original training set size:", len(training_epochs))
print("Filtered training set size:", len(training_epochs_filtered))



def reshape_meg_data(epochs, num_concepts, num_imgs, repetitions):
    data = epochs.get_data()
    reshaped_data = data.reshape((num_concepts, num_imgs, repetitions, data.shape[1], data.shape[2]))
    return reshaped_data


training_data = reshape_meg_data(training_epochs_filtered, num_concepts=1654, num_imgs=12, repetitions=1)
print("training_data.shape",training_data.shape)

zs_test_data = reshape_meg_data(zs_test_epochs, num_concepts=200, num_imgs=1, repetitions=12)
print("zs_test_data.shape",zs_test_data.shape)


def process_and_save_meg_data(fif_file, output_dir):
    epochs = read_and_crop_epochs(fif_file)

    sorted_indices = np.argsort(epochs.events[:, 2])
    epochs = epochs[sorted_indices]

    valid_epochs = filter_valid_epochs(epochs)
    zs_event_ids = identify_zs_event_ids(valid_epochs)

    training_epochs = valid_epochs[~np.isin(valid_epochs.events[:, 2], zs_event_ids)]
    zs_test_epochs = valid_epochs[np.isin(valid_epochs.events[:, 2], zs_event_ids)]

    keep_epochs_mask = [category not in test_set_categories for category in train_set_categories]
    training_epochs_filtered = training_epochs[keep_epochs_mask]

    training_data = reshape_meg_data(training_epochs_filtered, num_concepts=1654, num_imgs=12, repetitions=1)
    zs_test_data = reshape_meg_data(zs_test_epochs, num_concepts=200, num_imgs=1, repetitions=12)

    # Save data
    if not os.path.isdir(output_dir):
        os.makedirs(output_dir)
    save_data({'meg_data': training_data, 'ch_names': training_epochs_filtered.ch_names,
               'times': training_epochs_filtered.times},
              os.path.join(output_dir, 'preprocessed_meg_training.pkl'))
    save_data({'meg_data': zs_test_data, 'ch_names': zs_test_epochs.ch_names, 'times': zs_test_epochs.times},
              os.path.join(output_dir, 'preprocessed_meg_zs_test.pkl'))


def process_directory(input_dir, output_dir):
    fif_files = glob.glob(os.path.join(input_dir, '**/*epo.fif'), recursive=True)
    for fif_file in fif_files:
        filename = os.path.basename(fif_file)
        subject_num = filename.split('_')[1].split('-')[0]
        subject_dir_name = f"sub-{int(subject_num[1:]):02d}"
        subject_output_dir = os.path.join(output_dir, subject_dir_name)
        process_and_save_meg_data(fif_file, subject_output_dir)


"""
in_dir = "/nfs/nica-datashop/Things-data/Things-MEG_lyz/"
output_dir = "/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy"
process_directory(in_dir, output_dir)
"""

# 目标文件夹路径
folder_path = '/nfs/nica-datashop/Things-data/images'

# 初始化字典
folder_dict = {}

for i in range(1854):
    # 构建子文件夹路径
    subfolder_path = os.path.join(folder_path, str(i))

    # 检查子文件夹是否存在
    if os.path.exists(subfolder_path) and os.path.isdir(subfolder_path):
        # 遍历子文件夹中的文件
        for filename in os.listdir(subfolder_path):
            # 检查是否为文件
            if os.path.isfile(os.path.join(subfolder_path, filename)):
                # 提取文件名中最后一个'_'之前的部分
                file_part = filename.rsplit('_', 1)[0]
                # 将子文件夹名和文件名的一部分添加到字典中
                folder_dict[file_part] = str(i)
            else:
                print("空文件夹")
    else:
        print("文件夹不存在")

# 打印字典查看结果
print(folder_dict)


csv_img_file_path = "/nfs/diskstation/DataStation/public_dataset/Things_MEG/image_paths.csv"
image_df = pd.read_csv(csv_img_file_path, header=None)
concept_csv_file_path = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/image_concept_index.csv'
image_concept_df = pd.read_csv(concept_csv_file_path, header=None)


origin_img_dir = "/nfs/nica-datashop/Things-data/"

training_images_dir = "/nfs/diskstation/DataStation/public_dataset/Things_MEG/images_set/training_images"
test_images_dir = "/nfs/diskstation/DataStation/public_dataset/Things_MEG/images_set/test_images"

for index, row in tqdm(image_df.iterrows()):
    source_image_path = row[0]
    event_id = index + 1

    category_index = image_concept_df.iloc[event_id - 1, 0]

    path_parts = source_image_path.split('/')

    path_parts_source = source_image_path.split('/')
    idx = path_parts_source[1]
    path_parts_source[1] = folder_dict[idx]
    source_image_path = '/'.join(path_parts_source)

    if len(path_parts) > 2:
        formatted_index = str(category_index).zfill(5)
        path_parts[1] = f"{formatted_index}_{path_parts[1]}"

    image_path = os.path.join(path_parts[1],path_parts[2])

    if event_id in training_epochs_filtered.events[:, -1]:
        target_dir = os.path.join(training_images_dir)
    elif event_id in zs_test_epochs.events[:, -1]:
        target_dir = os.path.join(test_images_dir)
    else:
        continue

    src_file = os.path.join(origin_img_dir, source_image_path)
    dest_file = os.path.join(target_dir, image_path)

    os.makedirs(os.path.dirname(dest_file), exist_ok=True)

    shutil.copy(src_file, dest_file)



def count_images(directory):
    total_dirs = 0
    total_images = 0

    for entry in os.listdir(directory):
        path = os.path.join(directory, entry)
        if os.path.isdir(path):
            total_dirs += 1
            total_images += len([file for file in os.listdir(path) if os.path.isfile(os.path.join(path, file))])

    return total_dirs, total_images

num_dirs, num_images = count_images(training_images_dir)


print(f"There are {num_dirs} subdirectories in total")
print(f"All subdirectories together contain {num_images} images in total")
