import torch
import clip
import os
import numpy as np
import pickle


train_MEG_path = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy/sub-01/preprocessed_meg_training.pkl'

with open(train_MEG_path, 'rb') as train_file:
    train_data = pickle.load(train_file)

raw_train_MEG = np.squeeze(train_data['meg_data'])  #(1654, 12, 271, 201)
reshaped_MEG = []

for j in range(raw_train_MEG.shape[0]):
    data1 = raw_train_MEG[j,:,:,:]
    reshaped_MEG.append(data1)

train_MEG_data_1 = np.concatenate(reshaped_MEG, axis=0)
train_MEG_data_2 = np.squeeze(train_data['meg_data']).reshape(-1, 271, 201)   #(1654, 12, 1, 271, 201)     (class,  sample,  trial,   chanel,  time_points)

print(np.array_equal(train_MEG_data_1, train_MEG_data_2))







#EEG shape (200, 80, 63, 250)     (16540, 4, 63, 250)


