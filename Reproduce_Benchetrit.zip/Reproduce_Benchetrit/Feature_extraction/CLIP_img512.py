import torch
import clip
import os
import numpy as np
from tqdm import tqdm
from PIL import Image
import torchvision.transforms as transforms
device = torch.device('cuda:2')

weight_dtype = torch.float32
model, preprocess = clip.load("ViT-B/32", device=device)
model = model.to(torch.float32)
transform = transforms.Compose([
    transforms.RandomCrop(size=(400, 400)),
    transforms.CenterCrop(size=(224, 224)),
    transforms.Normalize(mean=(0.48145466, 0.4578275, 0.40821073), std=(0.26862954, 0.26130258, 0.27577711))
])

#Train
train_root = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/images_set/training_images/'
train_imgs1 = []
train_imgs2 = []
train_imgs3 = []

train_img_paths = []
for folder_name in os.listdir(train_root):
    train_img_paths.append(os.path.join(train_root, folder_name))

All_train_img_names = []
for folder_path in train_img_paths:
    for file_name in os.listdir(folder_path):
        All_train_img_names.append(os.path.join(folder_path, file_name))

for idx,train_img_file in tqdm(enumerate(All_train_img_names)):
    image = preprocess(Image.open(train_img_file)).unsqueeze(0).to(device)
    with torch.no_grad():
        image_features = model.encode_image(image).cpu().detach().numpy()
    if idx<9600:
        train_imgs1.append(image_features)
    elif idx>=9600 and idx<19200:
        train_imgs2.append(image_features)
    else:
        train_imgs3.append(image_features)

Train_1 = np.concatenate(train_imgs1,axis = 0)
np.save('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Train_clip_img_embeddings_1.npy',Train_1)

Train_2 = np.concatenate(train_imgs2,axis = 0)
np.save('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Train_clip_img_embeddings_2.npy',Train_2)

Train_3 = np.concatenate(train_imgs3,axis = 0)
np.save('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Train_clip_img_embeddings_3.npy',Train_3)

print('训练集特征提取完毕')

#Test
test_root = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/images_set/test_images/'
test_imgs = []

test_img_paths = []
for folder_name in os.listdir(test_root):
    test_img_paths.append(os.path.join(test_root, folder_name))

All_test_img_names = []
for folder_path in test_img_paths:
    for file_name in os.listdir(folder_path):
        All_test_img_names.append(os.path.join(folder_path, file_name))

for test_img_file in All_test_img_names:
    image = preprocess(Image.open(test_img_file)).unsqueeze(0).to(device)
    with torch.no_grad():
        image_features = model.encode_image(image).cpu().detach().numpy()
    test_imgs.append(image_features)

Test = np.concatenate(test_imgs,axis = 0)
np.save('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Test_clip_img_embeddings.npy',Test)

print('测试集特征提取完毕')


















