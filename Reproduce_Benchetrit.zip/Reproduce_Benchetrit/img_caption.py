#该代码需要在BLIP2环境中运行,
import torch
import os
import random
from tqdm import tqdm
import h5py
import numpy as np
dtype = h5py.special_dtype(vlen=str)
from PIL import Image
import clip
from lavis.models import load_model_and_preprocess
device = torch.device('cuda:5')
clip_model, clip_preprocess = clip.load("ViT-B/32", device=device)
model,vis_processors,_=load_model_and_preprocess(name="blip2_t5",model_type="pretrain_flant5xxl", is_eval=True, device=device)

#Train
train_root = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/images_set/training_images/'
train_img_paths = []
for folder_name in os.listdir(train_root):
    train_img_paths.append(os.path.join(train_root, folder_name))

All_train_img_names = []
for folder_path in train_img_paths:
    for file_name in os.listdir(folder_path):
        All_train_img_names.append(os.path.join(folder_path, file_name))

Train_Captions = []
for idx,train_img_file in tqdm(enumerate(All_train_img_names)):
    frame = Image.open(train_img_file).convert("RGB")
    frame1 = vis_processors["eval"](frame).unsqueeze(0).to(device)
    caption = model.generate({"image": frame1, "prompt": "Question: What does this image describe? Answer:"})
    Train_Captions.append(caption[0])

Train_Captions = np.array(Train_Captions , dtype=dtype)
f_Train = h5py.File('/nfs/diskstation/DataStation/public_dataset/Things_MEG/Train_captions.h5', 'w')
f_Train['Train_captions'] = Train_Captions
f_Train.close()


#Test
test_root = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/images_set/test_images/'
test_imgs = []

test_img_paths = []
for folder_name in os.listdir(test_root):
    test_img_paths.append(os.path.join(test_root, folder_name))

All_test_img_names = []
for folder_path in test_img_paths:
    for file_name in os.listdir(folder_path):
        All_test_img_names.append(os.path.join(folder_path, file_name))



Test_Captions = []
for idx,test_img_file in tqdm(enumerate(All_test_img_names)):
    frame = Image.open(test_img_file).convert("RGB")
    frame1 = vis_processors["eval"](frame).unsqueeze(0).to(device)
    caption = model.generate({"image": frame1, "prompt": "Question: What does this image describe? Answer:"})
    Test_Captions.append(caption[0])


Test_Captions = np.array(Test_Captions , dtype=dtype)
f_Test = h5py.File('/nfs/diskstation/DataStation/public_dataset/Things_MEG/Test_captions.h5', 'w')
f_Test['Test_captions'] = Test_Captions
f_Test.close()










