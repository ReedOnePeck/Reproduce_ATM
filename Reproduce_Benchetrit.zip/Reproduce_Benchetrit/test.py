import os

# 目标文件夹路径
folder_path = '/nfs/nica-datashop/Things-data/images'

# 初始化字典
folder_dict = {}

# 遍历文件夹
for i in range(1854):
    # 构建子文件夹路径
    subfolder_path = os.path.join(folder_path, str(i))

    # 检查子文件夹是否存在
    if os.path.exists(subfolder_path) and os.path.isdir(subfolder_path):
        # 遍历子文件夹中的文件
        for filename in os.listdir(subfolder_path):
            # 检查是否为文件
            if os.path.isfile(os.path.join(subfolder_path, filename)):
                # 提取文件名中最后一个'_'之前的部分
                file_part = filename.rsplit('_', 1)[0]
                # 将子文件夹名和文件名的一部分添加到字典中
                folder_dict[str(i)] = file_part
            else:
                print("空文件夹")
    else:
        print("文件夹不存在")

# 打印字典查看结果
print(len(folder_dict))
print(folder_dict)