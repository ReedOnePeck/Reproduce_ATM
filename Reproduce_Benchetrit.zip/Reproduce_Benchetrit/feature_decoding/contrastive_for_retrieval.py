import math
import mne
import torch
import pickle
from torch import nn
import numpy as np
import os
import torch
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import argparse
import h5py
import clip
from tqdm import tqdm
import matplotlib.pyplot as plt
from torch.optim import lr_scheduler
device = torch.device('cuda:2')


def zscore_eeg_data(eeg_data):
    """
    对EEG数据进行z-score标准化。

    参数:
    eeg_data : numpy.ndarray
        形状为(A, B, C)的numpy数组，其中A是数据个数，B是通道数，C是时间点数。

    返回:
    numpy.ndarray
        标准化后的EEG数据。
    """
    A, B, C = eeg_data.shape
    zscored_data = np.zeros_like(eeg_data)

    for b in range(B):
        # 计算每个通道的均值和标准差
        mu = np.mean(eeg_data[:, b, :], axis=1, keepdims=True)
        sigma = np.std(eeg_data[:, b, :], axis=1, keepdims=True)

        # 应用z-score标准化
        zscored_data[:, b, :] = (eeg_data[:, b, :] - mu) / sigma

    return zscored_data

class LayerScale(nn.Module):
    """Layer scale from [Touvron et al 2021] (https://arxiv.org/pdf/2103.17239.pdf).
    This rescales diagonaly residual outputs close to 0 initially, then learnt.
    """

    def __init__(self, channels: int, init: float = 0.1, boost: float = 5.):
        super().__init__()
        self.scale = nn.Parameter(torch.zeros(channels, requires_grad=True))
        self.scale.data[:] = init / boost
        self.boost = boost

    def forward(self, x):
        return (self.boost * self.scale[:, None]) * x

class LearnedAffineProjection(nn.Module):
    def __init__(self, input_dim, output_dim=1):
        super(LearnedAffineProjection, self).__init__()
        self.weight = nn.Parameter(torch.randn(input_dim,output_dim))
        self.bias = nn.Parameter(torch.zeros(output_dim))

    def forward(self, x):
        return torch.matmul(x, self.weight) + self.bias

class FourierEmb(nn.Module):
    """
    Fourier positional embedding.
    Unlike trad. embedding this is not using exponential periods
    for cosines and sinuses, but typical `2 pi k` which can represent
    any function over [0, 1]. As this function would be necessarily periodic,
    we take a bit of margin and do over [-0.2, 1.2].
    """

    def __init__(self, dimension: int = 256, margin: float = 0.2):
        super().__init__()
        n_freqs = (dimension // 2) ** 0.5
        assert int(n_freqs ** 2 * 2) == dimension
        self.dimension = dimension
        self.margin = margin

    def forward(self, positions):
        *O, D = positions.shape
        assert D == 2
        *O, D = positions.shape
        n_freqs = (self.dimension // 2) ** 0.5
        freqs_y = torch.arange(n_freqs).to(positions)
        freqs_x = freqs_y[:, None]
        width = 1 + 2 * self.margin
        positions = positions + self.margin
        p_x = 2 * math.pi * freqs_x / width
        p_y = 2 * math.pi * freqs_y / width
        positions = positions[..., None, None, :]
        loc = (positions[..., 0] * p_x + positions[..., 1] * p_y).view(*O, -1)
        emb = torch.cat([
            torch.cos(loc),
            torch.sin(loc),
        ], dim=-1)
        return emb

class Brain_Encoder_MEG_2CLIP_img(nn.Module):
    def __init__(self, feature_dimention, width_of_window, channel_dropout, dropout, n_block2, pos_dim=2048):
        """
        :param feature_dimention: 下游任务所用的特征维度
        :param width_of_window: 时间窗的宽度，用于构建时间聚合函数将时间窗维度压缩为1
        :param channel_dropout: channel_dropout的比率（0,1）
        :param dropout: 普通dropout的比率（0,1）
        :param n_block2:第二个残差连接卷积核的数量
        """
        super().__init__()
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))
        # SA
        initial_channels = 271
        self.channel_dropout = channel_dropout
        self.embedding = FourierEmb(pos_dim)
        self.heads = nn.Parameter(torch.randn(initial_channels, pos_dim, requires_grad=True))
        self.heads.data /= pos_dim ** 0.5

        # initial_linear
        linear_channels = 270
        self.activation = nn.GELU()
        self.initial_linear = nn.Sequential(
            nn.Conv1d(in_channels=initial_channels, out_channels=linear_channels, kernel_size=1),
            nn.GELU(),
            nn.Conv1d(in_channels=linear_channels, out_channels=linear_channels, kernel_size=1))

        # Conv
        # 注意参数设置保证时间维度不改变
        Conv_channels = 320
        Upsample_channels = 512
        kernel_size = 3
        dilation1 = 1
        dilation2 = 3
        self.n_block2 = n_block2
        self.Conv_block1 = nn.ModuleList([nn.Conv1d(in_channels=linear_channels, out_channels=Conv_channels,
                                                    kernel_size=kernel_size, stride=1, dilation=dilation1,
                                                    padding=int(((kernel_size - 1) * dilation1) / 2)),
                                          nn.BatchNorm1d(num_features=Conv_channels),
                                          nn.GELU(),
                                          nn.Dropout(dropout),
                                          ])


        self.Conv_block2 = nn.ModuleList([nn.Conv1d(in_channels=Conv_channels, out_channels=Conv_channels,
                                                    kernel_size=kernel_size, stride=1, dilation=dilation2,
                                                    padding=int(((kernel_size - 1) * dilation2) / 2)),
                                          nn.BatchNorm1d(num_features=Conv_channels),
                                          nn.GELU(),
                                          nn.Dropout(dropout),
                                          ])


        # Linear
        self.middle_linear = nn.ConvTranspose1d(in_channels=Conv_channels, out_channels=Upsample_channels,
                                                kernel_size=1,
                                                stride=1, padding=0, bias=True)

        # Time_agregation
        self.Time_agregation = LearnedAffineProjection(input_dim=width_of_window)

        # MLP_projector
        #self.MLP_projector_CLIP = nn.Linear(Upsample_channels, feature_dimention)
        self.MLP_projector_ldm = nn.Linear(Upsample_channels, 512)


    def forward(self, positions, batch_MEG, y_CLIP_t=None, y_CLIP_i=None):
        #x = self.Spatial_Attention(positions, batch_MEG)
        x = batch_MEG
        x = self.initial_linear(x)
        for module in self.Conv_block1:
            x = module(x)

        for j in range(self.n_block2):
            for module in self.Conv_block2:
                old_x = x
                x = module(x)
                x = x + old_x

        x = self.middle_linear(x)
        x = torch.squeeze(self.Time_agregation(x), dim=2)
        y = self.MLP_projector_ldm(x)
        #x = self.MLP_projector_CLIP(x)
        if y_CLIP_t is None:
            return y.view(-1, 512)
        else:
            logit_scale = self.logit_scale.exp()
            fMRI_embeds = x / x.norm(p=2, dim=-1, keepdim=True)
            image_embeds = y_CLIP_i / y_CLIP_i.norm(p=2, dim=-1, keepdim=True)
            text_embeds = y_CLIP_t / y_CLIP_t.norm(p=2, dim=-1, keepdim=True)

            logits_per_fMRI_t = torch.matmul(fMRI_embeds, text_embeds.t()) * logit_scale
            logits_per_fMRI_i = torch.matmul(fMRI_embeds, image_embeds.t()) * logit_scale

            return y.view(-1, 512), y.view(-1, 512), logits_per_fMRI_t, logits_per_fMRI_i


def make_model(feature_dim=768, width_of_window = 201, channel_dropout=0.2, dropout=0.2, n_block2=1):
    model = Brain_Encoder_MEG_2CLIP_img(feature_dimention = feature_dim, width_of_window = width_of_window, channel_dropout=channel_dropout, dropout=dropout, n_block2=n_block2)
    for p in model.parameters():
        if p.dim() > 1:
            nn.init.xavier_uniform(p)
    return model

# ----------------------------------------------------------Train------------------------------------------------------------------
class NoamOpt:
    "Optim wrapper that implements rate."

    def __init__(self, model_size, factor, warmup, optimizer):
        self.optimizer = optimizer
        self._step = 0
        self.warmup = warmup
        self.factor = factor
        self.model_size = model_size
        self._rate = 0.01

    def step(self):
        "Update parameters and rate"
        self._step += 1
        rate = self.rate()
        for p in self.optimizer.param_groups:
            p['lr'] = rate
        self._rate = rate
        self.optimizer.step()

    def rate(self, step=None):
        "Implement `lrate` above"
        if step is None:
            step = self._step
        return self.factor * \
               (self.model_size ** (-0.5) *
                min(step ** (-0.5), step * self.warmup ** (-1.5)))


def contrastive_loss(logits):
    return nn.functional.cross_entropy(logits, torch.arange(len(logits), device=logits.device))


def clip_loss(similarity):
    caption_loss = contrastive_loss(similarity)
    image_loss = contrastive_loss(similarity.t())
    return (caption_loss + image_loss) / 2.0


class Contrastive_loss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, logits_per_unit):
        loss = clip_loss(logits_per_unit)
        return loss


class SimpleLossCompute:
    def __init__(self, criterion1, criterion2, k1, k2,  opt=None):
        self.criterion1 = criterion1
        self.criterion2 = criterion2
        self.k1 = k1
        self.k2 = k2
        self.opt = opt

    def __call__(self, mode, epoch=None,y_pred=None, regularization=None, y_pred_mid=None, logits_per_fMRI_t=None,
                 logits_per_fMRI_i=None, y_tgt=None, y_CLIP_t=None, y_CLIP_i=None, norm=None):
        if mode == 'train':
            loss_pre = self.criterion2(y_pred_mid, y_CLIP_i) / norm
            loss_fMRI_text = self.criterion1(logits_per_fMRI_t) / norm
            loss_fMRI_img = self.criterion1(logits_per_fMRI_i) / norm
            #loss_proj = self.criterion2(y_pred, y_tgt) / norm
            loss_contrast = 0.5 * (loss_fMRI_text + loss_fMRI_img)


            #print("loss_pre:",loss_pre)
            #print("loss_contrast:", loss_contrast)
            #print("loss_proj:", loss_proj)


            #loss = 0.2 * loss_pre + self.k1 * loss_contrast + self.k2 * loss_proj
            loss =  0.02 * loss_pre + self.k1 * loss_contrast
            #print("train_loss:", loss)

            return loss

        else:
            loss_pre = self.criterion2(y_pred_mid, y_CLIP_i) / norm
            loss_fMRI_text = self.criterion1(logits_per_fMRI_t) / norm
            loss_fMRI_img = self.criterion1(logits_per_fMRI_i) / norm
            #loss_proj = self.criterion2(y_pred, y_tgt) / norm
            loss_contrast = 0.5 * (loss_fMRI_text + loss_fMRI_img)


            #loss = 0.2 * loss_pre + self.k1 * loss_contrast + self.k2 * loss_proj
            loss =  0.02 * loss_pre + self.k1 * loss_contrast

            return  loss.data.item() * norm

def run_epoch(mode, data_iter, model, loss_compute, norm=1, epoch=None, opt=None, scheduler=None):
    train_loss = []
    val_loss = []
    for i, batch in tqdm(enumerate(data_iter)):
        if mode == 'train':
            trn_loc, trn_src, trn_proj, trn_tgt_CLIP_text, trn_tgt_CLIP_picture = batch
            x, y, logits_per_fMRI_t, logits_per_fMRI_i = model.forward(positions = 0,
                                                                       batch_MEG=trn_src.squeeze(1),
                                                                       y_CLIP_t=trn_tgt_CLIP_text.squeeze(1),
                                                                       y_CLIP_i=trn_tgt_CLIP_picture.squeeze(1))
            loss = loss_compute(mode=mode, epoch=epoch, y_pred_mid=x,y_CLIP_t=trn_tgt_CLIP_text.squeeze(1),y_CLIP_i=trn_tgt_CLIP_picture.squeeze(1),
                                y_pred=y, y_tgt=trn_proj,
                                logits_per_fMRI_t=logits_per_fMRI_t,logits_per_fMRI_i=logits_per_fMRI_i, norm=norm)

            opt.zero_grad()
            loss.backward()
            opt.step()
            train_loss.append(loss.data.item() )

        if mode == 'val':
            val_loc, val_src, val_proj, val_tgt_CLIP_text, val_tgt_CLIP_picture = batch
            x, y, logits_per_fMRI_t, logits_per_fMRI_i = model.forward(positions = 0,
                                                                       batch_MEG=val_src.squeeze(1),
                                                                       y_CLIP_t=val_tgt_CLIP_text.squeeze(1),
                                                                       y_CLIP_i=val_tgt_CLIP_picture.squeeze(1))
            v_loss = loss_compute(mode=mode, epoch=epoch, y_pred_mid=x,y_CLIP_t=val_tgt_CLIP_text.squeeze(1),y_CLIP_i=val_tgt_CLIP_picture.squeeze(1),
                                  y_pred=y, y_tgt=val_proj,
                                logits_per_fMRI_t=logits_per_fMRI_t,logits_per_fMRI_i=logits_per_fMRI_i, norm=norm)
            val_loss.append(v_loss)


    if scheduler is not None:
        scheduler.step()
        #print('学习率是{}'.format(opt.state_dict()['param_groups'][0]['lr']))


    return train_loss, val_loss




for sub_ject_ID in ['2','3','4']:

    weight_dtype = torch.float32
    train_MEG_path = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy/sub-0{}/preprocessed_meg_training.pkl'.format(sub_ject_ID)
    val_MEG_path = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy/sub-0{}/preprocessed_meg_zs_test.pkl'.format(sub_ject_ID)

    with open(train_MEG_path, 'rb') as train_file:
        train_data = pickle.load(train_file)


    train_MEG_data = torch.tensor(zscore_eeg_data(np.squeeze(train_data['meg_data']).reshape(-1, 271, 201)), dtype=torch.float32).to(device)    #(1654, 12, 1, 271, 201)     (class,  sample,  trial,   chanel,  time_points)


    with open(val_MEG_path, 'rb') as val_file:
        val_data = pickle.load(val_file)
    val_MEG_data = torch.tensor(zscore_eeg_data(np.mean(np.squeeze(val_data['meg_data']), axis=1)), dtype=torch.float32).to(device)         #(200, 1, 12, 271, 201)


    CLIP_img1 = torch.tensor(np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Train_clip_img_embeddings_1.npy'), dtype=torch.float32)
    CLIP_img2 = torch.tensor(np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Train_clip_img_embeddings_2.npy'), dtype=torch.float32)
    CLIP_img3 = torch.tensor(np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Train_clip_img_embeddings_3.npy'), dtype=torch.float32)

    train_tgt_CLIP_img = torch.concat([CLIP_img1, CLIP_img2, CLIP_img3], dim=0).to(device)
    print(train_tgt_CLIP_img.shape)
    train_tgt_CLIP_text = torch.tensor(np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_text_512/Train_text_embeddings_CLIP_512.npy'), dtype=torch.float32).to(device)
    print(train_tgt_CLIP_text.shape)

    val_tgt_CLIP_img = torch.tensor(np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Test_clip_img_embeddings.npy'), dtype=torch.float32).to(device)
    val_tgt_CLIP_text = torch.tensor(np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_text_512/Test_text_embeddings_CLIP_512.npy'), dtype=torch.float32).to(device)

    class Train_dataset(Dataset):
        def __init__(self, sliding_window_start):
            #MEG
            self.trn_MEG = train_MEG_data#train_MEG_data[:,:,self.start:self.start+450]
            #Img
            self.trn_tgt_CLIP_picture = train_tgt_CLIP_img

            #Text
            self.trn_tgt_CLIP_text = train_tgt_CLIP_text

            self.size = train_tgt_CLIP_text.shape[0]


        def __len__(self):
            data_size = self.size
            return data_size

        def __getitem__(self, item):
            trn_MEG = self.trn_MEG[item:item + 1, :, :]

            text_embedding = 0

            trn_tgt_CLIP_picture = self.trn_tgt_CLIP_picture[item:item + 1, :]

            trn_tgt_CLIP_text = self.trn_tgt_CLIP_text[item:item + 1, :]

            trn_loc = 0
            return trn_loc, trn_MEG, text_embedding, trn_tgt_CLIP_text, trn_tgt_CLIP_picture

    class Val_dataset(Dataset):
        def __init__(self, sliding_window_start):
            self.test_src = val_MEG_data#val_MEG_data[:,:,self.start:self.start+450]
            self.test_tgt_CLIP_text = val_tgt_CLIP_text
            self.test_tgt_CLIP_picture = val_tgt_CLIP_img

            self.size = self.test_tgt_CLIP_text.shape[0]

        def __len__(self):
            data_size = self.size
            return data_size

        def __getitem__(self, item):
            test_src = self.test_src[item:item + 1, :, :]
            test_tgt = 0
            test_tgt_CLIP_text = self.test_tgt_CLIP_text[item:item + 1, :]
            test_tgt_CLIP_picture = self.test_tgt_CLIP_picture[item:item + 1, :]
            test_loc = 0
            return test_loc, test_src, test_tgt, test_tgt_CLIP_text, test_tgt_CLIP_picture






    parser = argparse.ArgumentParser(description='MEG_Semantic_decoding')
    parser.add_argument('--model_dir', help='model saved path', default='/data0/home/luyizhuo/Things_MEG/weights/sub{}/retrieval_models/',type=str)
    parser.add_argument('--figure_dir', help='figure saved path', default='/data0/home/luyizhuo/Things_MEG/weights/sub{}/retrieval_models/pictures/',type=str)
    parser.add_argument('--batch_size', help='batch size of dnn training', default=64, type=int)
    parser.add_argument('--epoch', help='epoch', default=100, type=int)
    parser.add_argument('--n_blocks', help='n_mlp_blocks', default=1, type=float)
    parser.add_argument('--k1', help='ratio of loss_CLIP', default=1, type=float)
    parser.add_argument('--k2', help='ratio of loss_raw', default=1, type=float)
    parser.add_argument('--lr', help='learning rate', default=2e-5, type=float)
    parser.add_argument('--warm_up', help='warm_up', default=30, type=float)
    parser.add_argument('--sliding_window', help='sliding_window_start', default=0, type=float)
    args = parser.parse_args()

    if not os.path.exists(args.model_dir.format(sub_ject_ID)):
        os.makedirs(args.model_dir.format(sub_ject_ID))

    if not os.path.exists(args.figure_dir.format(sub_ject_ID)):
        os.makedirs(args.figure_dir.format(sub_ject_ID))

    criterion1 = Contrastive_loss()
    criterion2 = nn.MSELoss()
    model = make_model(feature_dim=512, width_of_window = 201, channel_dropout=0.2, dropout=0.2, n_block2=args.n_blocks).to(device)
    model_opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = lr_scheduler.ExponentialLR(model_opt, gamma=0.999)

    trainset = Train_dataset(sliding_window_start=args.sliding_window)
    validation_set = Val_dataset(sliding_window_start = args.sliding_window)

    Train_loss = []
    Val_loss = []

    for epoch in tqdm(range(args.epoch + 1)):
        model.train()
        train_data = DataLoader(trainset, batch_size=args.batch_size, shuffle=True)
        train_loss, _ = run_epoch(mode='train', data_iter=train_data, model=model,
                                     loss_compute=SimpleLossCompute(
                                            criterion1=criterion1, criterion2=criterion2,k1=args.k1, k2=args.k2 ),
                                      norm=1, epoch=epoch,opt=model_opt, scheduler=scheduler)

        Train_loss.append(np.mean(train_loss))
        if epoch in [5, 10, 20,30,40,50,60,70,80,90,100,120,140,160,180,200]:  #120
            torch.save(model.state_dict(), os.path.join(args.model_dir.format(sub_ject_ID), 'MEG_semantic_decoder_{}.pth'.format(epoch)))



        model.eval()
        val_data = DataLoader(validation_set, batch_size=args.batch_size, shuffle=False)
        _, val_loss = run_epoch(mode='val', data_iter=val_data, model=model,
                                      loss_compute=SimpleLossCompute(
                                          criterion1=criterion1, criterion2=criterion2,k1=args.k1, k2=args.k2),
                                      norm=1, epoch=epoch)
        Val_loss.append(np.mean(val_loss))



        if epoch in [50,100,150,200]:
            epochs = range(len(Train_loss))
            plt.plot(epochs, Train_loss, 'red', label='Train_loss')
            plt.plot(epochs, Val_loss, 'green', label='Val_loss')

            plt.title('Loss-epoch{}'.format(epoch))
            plt.legend(loc='upper right')

            plt.savefig(args.figure_dir.format(sub_ject_ID)+'Loss-epoch{}.png'.format(epoch))
            plt.show()







