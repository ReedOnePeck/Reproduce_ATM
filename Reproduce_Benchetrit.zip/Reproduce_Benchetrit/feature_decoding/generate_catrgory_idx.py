import random
import numpy as np
import math
import pickle
import torch
SEED = 42
if SEED is not None:
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    random.seed(SEED)
from sklearn.metrics.pairwise import cosine_similarity
import h5py
from torch import nn
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
from tqdm import tqdm
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
device = torch.device('cuda:0')

class LayerScale(nn.Module):
    """Layer scale from [Touvron et al 2021] (https://arxiv.org/pdf/2103.17239.pdf).
    This rescales diagonaly residual outputs close to 0 initially, then learnt.
    """

    def __init__(self, channels: int, init: float = 0.1, boost: float = 5.):
        super().__init__()
        self.scale = nn.Parameter(torch.zeros(channels, requires_grad=True))
        self.scale.data[:] = init / boost
        self.boost = boost

    def forward(self, x):
        return (self.boost * self.scale[:, None]) * x

class LearnedAffineProjection(nn.Module):
    def __init__(self, input_dim, output_dim=1):
        super(LearnedAffineProjection, self).__init__()
        self.weight = nn.Parameter(torch.randn(input_dim,output_dim))
        self.bias = nn.Parameter(torch.zeros(output_dim))

    def forward(self, x):
        return torch.matmul(x, self.weight) + self.bias

class FourierEmb(nn.Module):
    """
    Fourier positional embedding.
    Unlike trad. embedding this is not using exponential periods
    for cosines and sinuses, but typical `2 pi k` which can represent
    any function over [0, 1]. As this function would be necessarily periodic,
    we take a bit of margin and do over [-0.2, 1.2].
    """

    def __init__(self, dimension: int = 256, margin: float = 0.2):
        super().__init__()
        n_freqs = (dimension // 2) ** 0.5
        assert int(n_freqs ** 2 * 2) == dimension
        self.dimension = dimension
        self.margin = margin

    def forward(self, positions):
        *O, D = positions.shape
        assert D == 2
        *O, D = positions.shape
        n_freqs = (self.dimension // 2) ** 0.5
        freqs_y = torch.arange(n_freqs).to(positions)
        freqs_x = freqs_y[:, None]
        width = 1 + 2 * self.margin
        positions = positions + self.margin
        p_x = 2 * math.pi * freqs_x / width
        p_y = 2 * math.pi * freqs_y / width
        positions = positions[..., None, None, :]
        loc = (positions[..., 0] * p_x + positions[..., 1] * p_y).view(*O, -1)
        emb = torch.cat([
            torch.cos(loc),
            torch.sin(loc),
        ], dim=-1)
        return emb


class Brain_Encoder_MEG_2CLIP_img(nn.Module):
    def __init__(self, feature_dimention, width_of_window, channel_dropout, dropout, n_block2, pos_dim=2048):
        """
        :param feature_dimention: 下游任务所用的特征维度
        :param width_of_window: 时间窗的宽度，用于构建时间聚合函数将时间窗维度压缩为1
        :param channel_dropout: channel_dropout的比率（0,1）
        :param dropout: 普通dropout的比率（0,1）
        :param n_block2:第二个残差连接卷积核的数量
        """
        super().__init__()
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))
        # SA
        initial_channels = 271
        self.channel_dropout = channel_dropout
        self.embedding = FourierEmb(pos_dim)
        self.heads = nn.Parameter(torch.randn(initial_channels, pos_dim, requires_grad=True))
        self.heads.data /= pos_dim ** 0.5

        # initial_linear
        linear_channels = 270
        self.activation = nn.GELU()
        self.initial_linear = nn.Sequential(
            nn.Conv1d(in_channels=initial_channels, out_channels=linear_channels, kernel_size=1),
            nn.GELU(),
            nn.Conv1d(in_channels=linear_channels, out_channels=linear_channels, kernel_size=1))

        # Conv
        # 注意参数设置保证时间维度不改变
        Conv_channels = 320
        Upsample_channels = 512
        kernel_size = 3
        dilation1 = 1
        dilation2 = 3
        self.n_block2 = n_block2
        self.Conv_block1 = nn.ModuleList([nn.Conv1d(in_channels=linear_channels, out_channels=Conv_channels,
                                                    kernel_size=kernel_size, stride=1, dilation=dilation1,
                                                    padding=int(((kernel_size - 1) * dilation1) / 2)),
                                          nn.BatchNorm1d(num_features=Conv_channels),
                                          nn.GELU(),
                                          nn.Dropout(dropout),
                                          ])


        self.Conv_block2 = nn.ModuleList([nn.Conv1d(in_channels=Conv_channels, out_channels=Conv_channels,
                                                    kernel_size=kernel_size, stride=1, dilation=dilation2,
                                                    padding=int(((kernel_size - 1) * dilation2) / 2)),
                                          nn.BatchNorm1d(num_features=Conv_channels),
                                          nn.GELU(),
                                          nn.Dropout(dropout),

                                          ])


        # Linear
        self.middle_linear = nn.ConvTranspose1d(in_channels=Conv_channels, out_channels=Upsample_channels,
                                                kernel_size=1,
                                                stride=1, padding=0, bias=True)

        # Time_agregation
        self.Time_agregation = LearnedAffineProjection(input_dim=width_of_window)

        # MLP_projector
        #self.MLP_projector_CLIP = nn.Linear(Upsample_channels, feature_dimention)
        self.MLP_projector_ldm = nn.Linear(Upsample_channels, 512)


    def forward(self, positions, batch_MEG, y_CLIP_t=None, y_CLIP_i=None):
        #x = self.Spatial_Attention(positions, batch_MEG)
        x = batch_MEG
        x = self.initial_linear(x)
        for module in self.Conv_block1:
            x = module(x)

        for j in range(self.n_block2):
            for module in self.Conv_block2:
                old_x = x
                x = module(x)
                x = x + old_x

        x = self.middle_linear(x)
        x = torch.squeeze(self.Time_agregation(x), dim=2)
        y = self.MLP_projector_ldm(x)
        #x = self.MLP_projector_CLIP(x)
        if y_CLIP_t is None:
            return y.view(-1, 512)
        else:
            logit_scale = self.logit_scale.exp()
            fMRI_embeds = x / x.norm(p=2, dim=-1, keepdim=True)
            image_embeds = y_CLIP_i / y_CLIP_i.norm(p=2, dim=-1, keepdim=True)
            text_embeds = y_CLIP_t / y_CLIP_t.norm(p=2, dim=-1, keepdim=True)

            logits_per_fMRI_t = torch.matmul(fMRI_embeds, text_embeds.t()) * logit_scale
            logits_per_fMRI_i = torch.matmul(fMRI_embeds, image_embeds.t()) * logit_scale

            return y.view(-1, 512), y.view(-1, 512), logits_per_fMRI_t, logits_per_fMRI_i

def top_k_accuracy(data, queries, labels, k=1):
    correct = 0
    total = len(queries)

    for idx, query in enumerate(queries):
        # 计算查询和数据集中每个点的余弦相似度
        sim = cosine_similarity([query], data).flatten()
        # 根据相似度排序，找出top-k的索引
        top_k_indices = sim.argsort()[-k:][::-1]

        # 检查正确的索引是否在top-k中
        if labels[idx] in top_k_indices:
            correct += 1
            #print("idx",idx)
            #print("top_k_indices",top_k_indices)

    return correct / total

def zscore_eeg_data(eeg_data):
    """
    对EEG数据进行z-score标准化。

    参数:
    eeg_data : numpy.ndarray
        形状为(A, B, C)的numpy数组，其中A是数据个数，B是通道数，C是时间点数。

    返回:
    numpy.ndarray
        标准化后的EEG数据。
    """
    A, B, C = eeg_data.shape
    zscored_data = np.zeros_like(eeg_data)

    for b in range(B):
        # 计算每个通道的均值和标准差
        mu = np.mean(eeg_data[:, b, :], axis=1, keepdims=True)
        sigma = np.std(eeg_data[:, b, :], axis=1, keepdims=True)

        # 应用z-score标准化
        zscored_data[:, b, :] = (eeg_data[:, b, :] - mu) / sigma

    return zscored_data


Subs = [1,2,3,4]

for sub in tqdm(Subs):
    weight_dtype = torch.float32
    val_MEG_path = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy/sub-0{}/preprocessed_meg_zs_test.pkl'.format(sub)

    with open(val_MEG_path, 'rb') as val_file:
        val_data = pickle.load(val_file)
    val_MEG_data = torch.tensor(zscore_eeg_data(np.mean(np.squeeze(val_data['meg_data']), axis=1)),
                                dtype=torch.float32).to(device)  # (200, 1, 12, 271, 201)



    # 对c的解码
    semantic_decoder = Brain_Encoder_MEG_2CLIP_img(feature_dimention=512, width_of_window=201, channel_dropout=0,
                                                   dropout=0, n_block2=1)
    semantic_decoder.load_state_dict(
        torch.load(f'/data0/home/luyizhuo/Things_MEG/weights/sub{sub}/retrieval_models/MEG_semantic_decoder_90.pth',
                   map_location=torch.device('cuda:0')))
    semantic_decoder.to(device)
    semantic_decoder.eval()

    # test_set_CLIP_emb_trivial_test = np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_for_img_recons/sub01/stimuli/trivial_test/contrastive/trivial_test_img_embeddings_CLIP_512.npy')
    img_features_all = np.load(
        '/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Test_clip_img_embeddings.npy')

    meg_emb = semantic_decoder(positions = 0, batch_MEG = val_MEG_data).cpu().detach().numpy()

    all_labels = set(range(200))
    selected_classes = list(all_labels)

    Labels = []
    for j, label in enumerate(all_labels):
        meg_feature = meg_emb[j:j + 1, :]
        logits_img = meg_feature @ img_features_all.T
        predicted_label = selected_classes[np.argmax(logits_img).item()]
        Labels.append(predicted_label)

    np.save(f'/data0/home/luyizhuo/Things_MEG/weights/sub{sub}/test_labels.npy',Labels)
