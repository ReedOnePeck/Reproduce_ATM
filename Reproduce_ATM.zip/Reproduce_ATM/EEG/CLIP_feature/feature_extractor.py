import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os
from sklearn.preprocessing import StandardScaler
import torch
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
import torchvision
from torchvision import transforms
from packages import model_options as MO
from packages import feature_extraction_detach as FE
from PIL import Image

os.environ['CUDA_VISIBLE_DEVICES'] = '2'
device = torch.device('cuda:0')

data_path = '/nfs/diskstation/DataStation/public_dataset/Things-EEG-data/Preprocessed_data_250Hz'
img_directory_training = '/nfs/diskstation/DataStation/public_dataset/Things-EEG-stimuli/training_images'
img_directory_test = '/nfs/diskstation/DataStation/public_dataset/Things-EEG-stimuli/test_images'

def load_data(train=True, classes=None,pictures=None,subjects=['sub-01'],exclude_subject=None):
    data_list = []
    label_list = []
    texts = []
    images = []

    if train:
        directory = img_directory_training
    else:
        directory = img_directory_test
    # 获取该路径下的所有目录
    dirnames = [d for d in os.listdir(directory) if os.path.isdir(os.path.join(directory, d))]
    dirnames.sort()

    if classes is not None:
        dirnames = [dirnames[i] for i in classes]

    for dir in dirnames:
        # 尝试找到第一个'_'的位置
        try:
            idx = dir.index('_')
            description = dir[idx + 1:]  # 从第一个'_'之后取得所有内容
        except ValueError:
            print(f"Skipped: {dir} due to no '_' found.")
            continue

        new_description = f"This picture is {description}"
        texts.append(new_description)

    if train:
        img_directory = img_directory_training  # 请将其替换为你的新地址
    else:
        img_directory = img_directory_test

    all_folders = [d for d in os.listdir(img_directory) if os.path.isdir(os.path.join(img_directory, d))]
    all_folders.sort()  # 保证文件夹的顺序

    if classes is not None and pictures is not None:
        images = []  # 初始化images列表
        for i in range(len(classes)):
            class_idx = classes[i]
            pic_idx = pictures[i]
            if class_idx < len(all_folders):
                folder = all_folders[class_idx]
                folder_path = os.path.join(img_directory, folder)
                all_images = [img for img in os.listdir(folder_path) if
                              img.lower().endswith(('.png', '.jpg', '.jpeg'))]
                all_images.sort()
                if pic_idx < len(all_images):
                    images.append(os.path.join(folder_path, all_images[pic_idx]))
    elif classes is not None and pictures is None:
        images = []  # 初始化images列表
        for i in range(len(classes)):
            class_idx = classes[i]
            if class_idx < len(all_folders):
                folder = all_folders[class_idx]
                folder_path = os.path.join(img_directory, folder)
                all_images = [img for img in os.listdir(folder_path) if
                              img.lower().endswith(('.png', '.jpg', '.jpeg'))]
                all_images.sort()
                images.extend(os.path.join(folder_path, img) for img in all_images)
    elif classes is None:
        images = []  # 初始化images列表
        for folder in all_folders:
            folder_path = os.path.join(img_directory, folder)
            all_images = [img for img in os.listdir(folder_path) if img.lower().endswith(('.png', '.jpg', '.jpeg'))]
            all_images.sort()
            images.extend(os.path.join(folder_path, img) for img in all_images)
    else:
        # 处理其他情况，比如 self.classes 和 self.pictures 长度不匹配
        print("Error")

    print("self.subjects", subjects)

    for subject in subjects:
        if train:
            file_name = 'preprocessed_eeg_training.npy'

            file_path = os.path.join(data_path, subject, file_name)
            data = np.load(file_path, allow_pickle=True)

            preprocessed_eeg_data = torch.from_numpy(data['preprocessed_eeg_data']).float().detach()
            times = torch.from_numpy(data['times']).detach()[50:]
            ch_names = data['ch_names']  # 保留为 Python 列表，或者进行适当的编码

            n_classes = 1654  # 每个类包含10张图片
            samples_per_class = 10  # 一个类有十个数据

            if classes is not None and pictures is not None:
                for c, p in zip(classes, pictures):
                    start_index = c * 1 + p
                    if start_index < len(preprocessed_eeg_data):  # 确保索引不超出范围
                        preprocessed_eeg_data_class = preprocessed_eeg_data[start_index: start_index + 1]  # 只选择一条数据
                        labels = torch.full((1,), c, dtype=torch.long).detach()  # 添加类标签
                        data_list.append(preprocessed_eeg_data_class)
                        label_list.append(labels)  # 将标签添加到标签列表中

            elif classes is not None and pictures is None:
                for c in classes:
                    start_index = c * samples_per_class
                    preprocessed_eeg_data_class = preprocessed_eeg_data[
                                                  start_index: start_index + samples_per_class]
                    labels = torch.full((samples_per_class,), c, dtype=torch.long).detach()  # 添加类标签
                    data_list.append(preprocessed_eeg_data_class)
                    label_list.append(labels)

            else:
                for i in range(n_classes):
                    start_index = i * samples_per_class
                    # if self.exclude_subject==None:
                    #     preprocessed_eeg_data_class = preprocessed_eeg_data[start_index: start_index+samples_per_class]
                    # else:
                    preprocessed_eeg_data_class = preprocessed_eeg_data[
                                                  start_index: start_index + samples_per_class]
                    # print("preprocessed_eeg_data_class", preprocessed_eeg_data_class.shape)
                    # preprocessed_eeg_data_class = torch.mean(preprocessed_eeg_data_class, 1)
                    # preprocessed_eeg_data_class = torch.mean(preprocessed_eeg_data_class, 0)
                    # print("preprocessed_eeg_data_class", preprocessed_eeg_data_class.shape)
                    labels = torch.full((samples_per_class,), i, dtype=torch.long).detach()  # 添加类标签
                    data_list.append(preprocessed_eeg_data_class)
                    label_list.append(labels)


        else:
            if subject == exclude_subject or exclude_subject == None:  # 跳过被排除的被试                    :  # 跳过被排除的被试
                file_name = 'preprocessed_eeg_test.npy'
                file_path = os.path.join(data_path, subject, file_name)
                data = np.load(file_path, allow_pickle=True)
                preprocessed_eeg_data = torch.from_numpy(data['preprocessed_eeg_data']).float().detach()
                times = torch.from_numpy(data['times']).detach()[50:]
                ch_names = data['ch_names']  # 保留为 Python 列表，或者进行适当的编码
                n_classes = 200  # Each class contains 1 images

                samples_per_class = 1  # 一个类有1个数据

                for i in range(n_classes):
                    if classes is not None and i not in classes:  # If we've defined specific classes and the current class is not in the list, skip
                        continue
                    start_index = i * samples_per_class  # Update start_index for each class
                    preprocessed_eeg_data_class = preprocessed_eeg_data[start_index:start_index + samples_per_class]
                    # print("preprocessed_eeg_data_class", preprocessed_eeg_data_class.shape)
                    labels = torch.full((samples_per_class * 80,), i, dtype=torch.long).detach()  # Add class labels
                    # preprocessed_eeg_data_class = torch.mean(preprocessed_eeg_data_class.squeeze(0), 0)
                    # print("preprocessed_eeg_data_class", preprocessed_eeg_data_class.shape)
                    data_list.append(preprocessed_eeg_data_class)
                    label_list.append(labels)  # Add labels to the label list
            else:
                continue
    # datalist: (subjects * classes) * (10 * 4 * 17 * 100)
    # data_tensor: (subjects * classes * 10 * 4) * 17 * 100
    # data_list = np.mean(data_list, )
    # print("data_list", len(data_list))
    if train:
        # print("data_list", *data_list[0].shape[1:])
        data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape[2:])
        # data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape[1:])
        # data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape)
        # print("label_tensor", label_tensor.shape)
        print("data_tensor", data_tensor.shape)
    else:
        data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape[2:])
        # label_tensor = torch.cat(label_list, dim=0)
        # print("label_tensor", label_tensor.shape)
        # data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape[2:])
    # print("data_tensor", data_tensor.shape)
    # label_list: (subjects * classes) * 10
    # label_tensor: (subjects * classes * 10)
    # print("label_tensor = torch.cat(label_list, dim=0)")
    # print(label_list)
    label_tensor = torch.cat(label_list, dim=0)
    # label_tensor = torch.cat(label_list, dim=0)
    # print(label_tensor[:300])
    if train:
        # label_tensor: (subjects * classes * 10 * 4)
        label_tensor = label_tensor.repeat_interleave(4)
        if classes is not None:
            unique_values = list(label_tensor.numpy())
            lis = []
            for i in unique_values:
                if i not in lis:
                    lis.append(i)
            unique_values = torch.tensor(lis)
            mapping = {val.item(): index for index, val in enumerate(unique_values)}
            label_tensor = torch.tensor([mapping[val.item()] for val in label_tensor], dtype=torch.long)

    else:
        # label_tensor = label_tensor.repeat_interleave(80)
        # if self.classes is not None:
        #     unique_values = torch.unique(label_tensor, sorted=False)

        #     mapping = {val.item(): index for index, val in enumerate(torch.flip(unique_values, [0]))}
        #     label_tensor = torch.tensor([mapping[val.item()] for val in label_tensor], dtype=torch.long)
        pass

    return data_tensor, label_tensor, texts, images


def CLIP_extraction(data, target_layer):
    model_string = 'ViT-B/32_clip'
    model_option = MO.get_model_options()[model_string]
    image_transforms = MO.get_recommended_transforms(model_string)
    model_name = model_option['model_name']
    train_type = model_option['train_type']

    def retrieve_clip_model(model_name):
        import clip;
        model, _ = clip.load(model_name, device='cpu')
        return model.visual

    model = eval(model_option['call'])
    model = model.eval()
    model = model.to(device)

    transform_for_CLIP = torchvision.transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.Normalize(mean=(0.485, 0.456, 0.406),
        std=(0.229, 0.224, 0.225))
    ])

    class TensorDataset(Dataset):
        def __init__(self, data_tensor, image_transforms=None):
            self.data_tensor = data_tensor
            self.transforms = image_transforms

        def __getitem__(self, index):
            img = self.data_tensor[index]
            if self.transforms:
                img = self.transforms(img)
            return img

        def __len__(self):
            return self.data_tensor.size(0)

    #data_tensor = torch.tensor(np.load(filepath))#[8000:,:,:]
    data_tensor = data
    stimulus_loader = DataLoader(TensorDataset(data_tensor, transform_for_CLIP), batch_size=128)
    target_layers = target_layer
    feature_maps = FE.get_all_feature_maps(model, stimulus_loader, layers_to_retain=target_layers,
                                           remove_duplicates=False, numpy=True)


    for feature_map in feature_maps:
        feature = feature_maps[feature_map]
        print(feature_map, feature_maps[feature_map].shape)
        return feature

    del feature_maps
    torch.cuda.empty_cache()


target_layers = ['Linear-2', 'Linear-4', 'Linear-6', 'Linear-8', 'Linear-10', 'Linear-12']   # Linear-4:  76/130  Linear-6:  53/130 Linear-8:  41/130  Linear-10:  33/130 Linear-12:   28/130
_, _, _, train_images = load_data(train=True, classes=None,pictures=None,subjects=['sub-01'],exclude_subject=None)
imgs = torch.stack([torch.tensor(np.array(Image.open(img).convert("RGB")) / 255.) for img in train_images]).permute(0, 3, 1, 2).to(torch.float32)
#(16540,3,500,500)

target_layer = 'Linear-4'

image_inputs1 = imgs[:8270,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[8270:,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train2.npy'.format(target_layer),train_feature2)
print('训练集的{}特征提取完毕'.format(target_layer))


target_layer = 'Linear-6'

image_inputs1 = imgs[:5520,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[5520:5520+5520,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train2.npy'.format(target_layer),train_feature2)

image_inputs3 = imgs[5520+5520:,:,:,:]
train_feature3 = CLIP_extraction(image_inputs3, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train3.npy'.format(target_layer),train_feature3)
print('训练集的{}特征提取完毕'.format(target_layer))


target_layer = 'Linear-8'

image_inputs1 = imgs[:4135,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[4135:4135+4135,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train2.npy'.format(target_layer),train_feature2)

image_inputs3 = imgs[4135+4135:4135+4135+4135,:,:,:]
train_feature3 = CLIP_extraction(image_inputs3, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train3.npy'.format(target_layer),train_feature3)

image_inputs4 = imgs[4135+4135+4135:,:,:,:]
train_feature4 = CLIP_extraction(image_inputs4, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train4.npy'.format(target_layer),train_feature4)
print('训练集的{}特征提取完毕'.format(target_layer))


target_layer = 'Linear-10'

image_inputs1 = imgs[:3308,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[3308:3308+3308,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train2.npy'.format(target_layer),train_feature2)

image_inputs3 = imgs[3308+3308:3308+3308+3308,:,:,:]
train_feature3 = CLIP_extraction(image_inputs3, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train3.npy'.format(target_layer),train_feature3)

image_inputs4 = imgs[3308+3308+3308:3308+3308+3308+3308,:,:,:]
train_feature4 = CLIP_extraction(image_inputs4, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train4.npy'.format(target_layer),train_feature4)

image_inputs5 = imgs[3308+3308+3308+3308:,:,:,:]
train_feature5 = CLIP_extraction(image_inputs5, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train5.npy'.format(target_layer),train_feature5)
print('训练集的{}特征提取完毕'.format(target_layer))




target_layer = 'Linear-12'

image_inputs1 = imgs[:3308,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[3308:3308+3308,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train2.npy'.format(target_layer),train_feature2)

image_inputs3 = imgs[3308+3308:3308+3308+3308,:,:,:]
train_feature3 = CLIP_extraction(image_inputs3, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train3.npy'.format(target_layer),train_feature3)

image_inputs4 = imgs[3308+3308+3308:3308+3308+3308+3308,:,:,:]
train_feature4 = CLIP_extraction(image_inputs4, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train4.npy'.format(target_layer),train_feature4)

image_inputs5 = imgs[3308+3308+3308+3308:,:,:,:]
train_feature5 = CLIP_extraction(image_inputs5, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_train5.npy'.format(target_layer),train_feature5)
print('训练集的{}特征提取完毕'.format(target_layer))

"""

_, _, _, test_images = load_data(train=False, classes=None,pictures=None,subjects=['sub-01'],exclude_subject=None)

#for target_layer in target_layers:
image_inputs = torch.stack([torch.tensor(np.array(Image.open(img).convert("RGB")) / 255.) for img in test_images]).permute(0, 3, 1, 2).to(torch.float32)
test_feature = CLIP_extraction(image_inputs, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_test.npy'.format(target_layer),test_feature)
print('测试集的{}特征提取完毕'.format(target_layer))
"""








"""

"""






