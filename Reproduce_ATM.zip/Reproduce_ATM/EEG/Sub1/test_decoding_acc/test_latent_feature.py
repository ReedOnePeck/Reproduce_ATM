import os
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
from EEG_recons.EEG_dataset_for_vae_latent import EEGDataset
from einops.layers.torch import Rearrange, Reduce
from torch.utils.data import DataLoader, Dataset
from EEG_recons.util import wandb_logger
from torch import Tensor
import torch
import numpy as np
from EEG_recons.subject_layers.Transformer_EncDec import Encoder, EncoderLayer
from EEG_recons.subject_layers.SelfAttention_Family import FullAttention, AttentionLayer
from EEG_recons.subject_layers.Embed import DataEmbedding_inverted
import torch.nn as nn
import torch.optim.lr_scheduler as lr_scheduler
import argparse
import datetime
import itertools
import csv



class Config:
    def __init__(self):
        self.task_name = 'classification'  # Example task name
        self.seq_len = 250  # Sequence length
        self.pred_len = 250  # Prediction length
        self.output_attention = False  # Whether to output attention weights
        self.d_model = 250  # Model dimension
        self.embed = 'timeF'  # Time encoding method
        self.freq = 'h'  # Time frequency
        self.dropout = 0.1  # Dropout rate
        self.factor = 1  # Attention scaling factor
        self.n_heads = 4  # Number of attention heads
        self.e_layers = 3  # Number of encoder layers
        self.d_ff = 256  # Feed-forward network dimension
        self.activation = 'gelu'  # Activation function
        self.enc_in = 63  # Encoder input dimension (example value)



class encoder_low_level(nn.Module):
    def __init__(self, num_channels=63, sequence_length=250, num_subjects=1, num_features=64, num_latents=1024,
                 num_blocks=1):
        super(encoder_low_level, self).__init__()
        self.subject_wise_linear = nn.ModuleList([nn.Linear(sequence_length, 128) for _ in range(num_subjects)])
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))
        self.dropout = nn.Dropout(0.05)

        # CNN upsampler
        self.upsampler = nn.Sequential(
            nn.ConvTranspose2d(8064, 1024, kernel_size=4, stride=2, padding=1),  # (1, 1) -> (2, 2)
            nn.BatchNorm2d(1024),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(1024, 512, kernel_size=4, stride=2, padding=1),  # (2, 2) -> (4, 4)
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(512, 256, kernel_size=4, stride=2, padding=1),  # (4, 4) -> (8, 8)
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1),  # (8, 8) -> (16, 16)
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),  # (16, 16) -> (32, 32)
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1),  # (32, 32) -> (64, 64)
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(32, 16, kernel_size=1, stride=1, padding=0),  # Keep size (64, 64)
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(16, 4, kernel_size=1, stride=1, padding=0),  # Output shape (4, 64, 64)
        )

    def forward(self, x):
        # Apply subject-wise linear layer
        x = self.subject_wise_linear[0](x)  # Output shape: (batchsize, 63, 128)
        # Reshape to match the input size for the upsampler
        x = x.view(x.size(0), 8064, 1, 1)  # Reshape to (batch_size, 8064, 1, 1)
        out = self.upsampler(x)  # Pass through the upsampler
        return out



def cal_pccs(X, Y):
	XMean = np.mean(X)
	YMean = np.mean(Y)
	#标准差
	XSD = np.std(X)
	YSD = np.std(Y)
	#z分数
	ZX = (X-XMean)/(XSD+1e-30)
	ZY = (Y-YMean)/(YSD+1e-30)#相关系数
	r = np.sum(ZX*ZY)/(len(X))         #(len(X))
	return(r)

Subs = ['sub-02','sub-03','sub-04','sub-05']
for sub in Subs:

    data_path = '/nfs/diskstation/DataStation/public_dataset/Things-EEG-data/Preprocessed_data_250Hz'

    test_dataset = EEGDataset(data_path, subjects=[sub], train=False)
    img_features_test_all = np.array(test_dataset.img_features).reshape(200,-1)
    EEG_test = test_dataset.data.reshape(200, 80, 63, 250).mean(axis=1)

    eeg_model = encoder_low_level()


    file_path = f"/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/{sub}/latent_decoder/5.pth"
    eeg_model.load_state_dict(torch.load(file_path))

    # 3. 如果你想使用模型进行推理，记得将模型设置为评估模式
    eeg_model.eval()

    a = eeg_model(EEG_test).detach().numpy()#.reshape(200,-1)
    np.save(f'/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/recons_results/{sub}/latent_feature.npy', a)



"""
cor = []
for i in range(a.shape[0]):
    x = a[i, :]
    y = img_features_test_all[i, :]
    cor_i = cal_pccs(x, y)
    cor.append(abs(cor_i))


print(np.mean(cor))    #epoch:0.296
"""






