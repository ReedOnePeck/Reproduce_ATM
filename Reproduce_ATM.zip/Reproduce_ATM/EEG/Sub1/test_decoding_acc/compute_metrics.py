import os
import sys
import json
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import scipy as sp
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms
from torchvision.utils import make_grid
from tqdm import tqdm
from datetime import datetime
device = torch.device('cuda:5')



gts_folder = '/nfs/diskstation/DataStation/public_dataset/Things-EEG-stimuli/test_images/'
subfolders = sorted([f for f in os.listdir(gts_folder) if os.path.isdir(os.path.join(gts_folder, f))])
gt_imgs = np.zeros((200, 500, 500, 3), dtype=np.float32)
for j in range(200):
    folder_name = subfolders[j]
    folder_full_path = os.path.join(gts_folder, folder_name)
    img_name = os.listdir(folder_full_path)
    img_file = os.path.join(folder_full_path, img_name[0])
    img = Image.open(img_file)
    img_array = np.array(img, dtype=np.float32) / 255.0
    gt_imgs[j] = img_array



"""

subj_ID = '1'

recons_folder = '/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/recons_results/sub1/recons_with_ours/'
result = np.zeros((200, 512, 512, 3), dtype=np.float32)
for i in range(200):
    folder_name = f'picture_{i+1}'
    folder_full_path = os.path.join(recons_folder, folder_name)
    image_paths = [f for f in os.listdir(folder_full_path) if f.endswith('rec_iter_040.png')]  #rec_iter_040.png
    for j, image_path in enumerate(image_paths):
        image_full_path = os.path.join(folder_full_path, image_path)
        img = Image.open(image_full_path)
        img_array = np.array(img, dtype=np.float32) / 255.0
        result[i] = img_array
"""

subj_ID = '5'

recons_folder = f'/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/recons_results/sub-0{subj_ID}/reproduced_ATM/'
result = np.zeros((200, 512, 512, 3), dtype=np.float32)
for i in range(200):
    folder_full_path = recons_folder
    image_full_path = os.path.join(folder_full_path, f"img_{i+1}.png")
    img = Image.open(image_full_path)
    img_array = np.array(img, dtype=np.float32) / 255.0
    result[i] = img_array


result = np.transpose(result, (0, 3, 1, 2))
gt_imgs = np.transpose(gt_imgs, (0, 3, 1, 2))
all_images = torch.tensor(gt_imgs).to(device)
all_brain_recons = torch.tensor(result).to(all_images.dtype).clamp(0,1).to(device)
print(all_brain_recons.shape)

imsize = 256
all_images = transforms.Resize((imsize,imsize))(all_images)
all_brain_recons = transforms.Resize((imsize,imsize))(all_brain_recons)


#==================================================2-Way Identification=======================================================================
from torchvision.models.feature_extraction import create_feature_extractor, get_graph_node_names

@torch.no_grad()
def two_way_identification(all_brain_recons, all_images, model, preprocess, feature_layer=None, return_avg=True):
    preds = model(torch.stack([preprocess(recon) for recon in all_brain_recons], dim=0).to(device))
    reals = model(torch.stack([preprocess(indiv) for indiv in all_images], dim=0).to(device))
    if feature_layer is None:
        preds = preds.float().flatten(1).cpu().numpy()
        reals = reals.float().flatten(1).cpu().numpy()
    else:
        preds = preds[feature_layer].float().flatten(1).cpu().numpy()
        reals = reals[feature_layer].float().flatten(1).cpu().numpy()

    r = np.corrcoef(reals, preds)
    r = r[:len(all_images), len(all_images):]
    congruents = np.diag(r)

    success = r < congruents
    success_cnt = np.sum(success, 0)

    if return_avg:
        perf = np.mean(success_cnt) / (len(all_images)-1)
        return perf
    else:
        return success_cnt, len(all_images)-1

#================================================================PixCorr============================================================================
preprocess = transforms.Compose([
    transforms.Resize(425, interpolation=transforms.InterpolationMode.BILINEAR),
])

# Flatten images while keeping the batch dimension
all_images_flattened = preprocess(all_images).reshape(len(all_images), -1).cpu()
all_brain_recons_flattened = preprocess(all_brain_recons).reshape(len(all_brain_recons), -1).cpu()

print(all_images_flattened.shape)
print(all_brain_recons_flattened.shape)

corrsum = 0
for i in tqdm(range(200)):
    corrsum += np.corrcoef(all_images_flattened[i], all_brain_recons_flattened[i])[0][1]
corrmean = corrsum / 200

pixcorr = corrmean
print(pixcorr)


#===========================================================================SSIM====================================================================
# see https://github.com/zijin-gu/meshconv-decoding/issues/3
from skimage.color import rgb2gray
from skimage.metrics import structural_similarity as ssim

# convert image to grayscale with rgb2grey
img_gray = rgb2gray(preprocess(all_images).permute((0,2,3,1)).cpu())
recon_gray = rgb2gray(preprocess(all_brain_recons).permute((0,2,3,1)).cpu())
print("converted, now calculating ssim...")

ssim_score=[]
for im,rec in tqdm(zip(img_gray,recon_gray),total=len(all_images)):
    ssim_score.append(ssim(rec, im, multichannel=True, gaussian_weights=True, sigma=1.5, use_sample_covariance=False, data_range=1.0))

ssim = np.mean(ssim_score)
print(ssim)

#=======================================================================AlexNet===========================================================================
from torchvision.models import alexnet#, AlexNet_Weights
#alex_weights = AlexNet_Weights.IMAGENET1K_V1
#alex_model = create_feature_extractor(alexnet(weights=alex_weights), return_nodes=['features.4','features.11']).to(device)

alex_model = create_feature_extractor(alexnet(pretrained=True), return_nodes=['features.4','features.11']).to(device)
alex_model.eval().requires_grad_(False)

# see alex_weights.transforms()
preprocess = transforms.Compose([
    transforms.Resize(256, interpolation=transforms.InterpolationMode.BILINEAR),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]),
])

layer = 'early, AlexNet(2)'
print(f"\n---{layer}---")
all_per_correct = two_way_identification(all_brain_recons.to(device).float(), all_images,
                                                          alex_model, preprocess, 'features.4')
alexnet2 = np.mean(all_per_correct)
print(f"2-way Percent Correct: {alexnet2:.4f}")

layer = 'mid, AlexNet(5)'
print(f"\n---{layer}---")
all_per_correct = two_way_identification(all_brain_recons.to(device).float(), all_images,
                                                          alex_model, preprocess, 'features.11')
alexnet5 = np.mean(all_per_correct)
print(f"2-way Percent Correct: {alexnet5:.4f}")





#================================================================InceptionV3======================================================================

from torchvision.models import inception_v3#, Inception_V3_Weights

#weights = Inception_V3_Weights.DEFAULT
inception_model = create_feature_extractor(inception_v3(pretrained=True),
                                           return_nodes=['avgpool']).to(device)
inception_model.eval().requires_grad_(False)

# see weights.transforms()
preprocess = transforms.Compose([
    transforms.Resize(342, interpolation=transforms.InterpolationMode.BILINEAR),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]),
])

all_per_correct = two_way_identification(all_brain_recons, all_images,
                                         inception_model, preprocess, 'avgpool')

inception = np.mean(all_per_correct)
print(f"2-way Percent Correct: {inception:.4f}")



#======================================================CLIP======================================================================================

import clip
clip_model, preprocess = clip.load("ViT-L/14", device=device)

preprocess = transforms.Compose([
    transforms.Resize(224, interpolation=transforms.InterpolationMode.BILINEAR),
    transforms.Normalize(mean=[0.48145466, 0.4578275, 0.40821073],
                         std=[0.26862954, 0.26130258, 0.27577711]),
])

all_per_correct = two_way_identification(all_brain_recons, all_images,
                                        clip_model.encode_image, preprocess, None) # final layer
clip_ = np.mean(all_per_correct)
print(f"2-way Percent Correct: {clip_:.4f}")




#======================================================Efficient Net========================================================================
from torchvision.models import efficientnet_b1#, EfficientNet_B1_Weights
#weights = EfficientNet_B1_Weights.DEFAULT
eff_model = create_feature_extractor(efficientnet_b1(pretrained=True),
                                    return_nodes=['avgpool']).to(device)
eff_model.eval().requires_grad_(False)

# see weights.transforms()
preprocess = transforms.Compose([
    transforms.Resize(255, interpolation=transforms.InterpolationMode.BILINEAR),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]),
])

gt = eff_model(preprocess(all_images))['avgpool']
gt = gt.reshape(len(gt),-1).cpu().numpy()
fake = eff_model(preprocess(all_brain_recons))['avgpool']
fake = fake.reshape(len(fake),-1).cpu().numpy()

effnet = np.array([sp.spatial.distance.correlation(gt[i],fake[i]) for i in range(len(gt))]).mean()
print("Distance:",effnet)


#=============================================================SwAV==============================================================
swav_model = torch.hub.load('facebookresearch/swav:main', 'resnet50')
swav_model = create_feature_extractor(swav_model,
                                    return_nodes=['avgpool']).to(device)
swav_model.eval().requires_grad_(False)

preprocess = transforms.Compose([
    transforms.Resize(224, interpolation=transforms.InterpolationMode.BILINEAR),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]),
])

gt = swav_model(preprocess(all_images))['avgpool']
gt = gt.reshape(len(gt),-1).cpu().numpy()
fake = swav_model(preprocess(all_brain_recons))['avgpool']
fake = fake.reshape(len(fake),-1).cpu().numpy()

swav = np.array([sp.spatial.distance.correlation(gt[i],fake[i]) for i in range(len(gt))]).mean()
print("Distance:",swav)


#===============================================================================================

# Create a dictionary to store variable names and their corresponding values
data = {
    "Metric": ["PixCorr", "SSIM", "AlexNet(2)", "AlexNet(5)", "InceptionV3", "CLIP", "EffNet-B", "SwAV"],
    "Value": [pixcorr, ssim, alexnet2, alexnet5, inception, clip_, effnet, swav],
}

df = pd.DataFrame(data)
print(df.to_string(index=False))
