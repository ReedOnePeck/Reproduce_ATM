import os
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
from EEG_recons.EEG_dataset_for_vae_latent import EEGDataset
from einops.layers.torch import Rearrange, Reduce
from torch.utils.data import DataLoader, Dataset
from EEG_recons.util import wandb_logger
from torch import Tensor
import torch
import numpy as np
from EEG_recons.subject_layers.Transformer_EncDec import Encoder, EncoderLayer
from EEG_recons.subject_layers.SelfAttention_Family import FullAttention, AttentionLayer
from EEG_recons.subject_layers.Embed import DataEmbedding_inverted
import torch.nn as nn
import torch.optim.lr_scheduler as lr_scheduler
import argparse
import datetime
import itertools
import csv



class Config:
    def __init__(self):
        self.task_name = 'classification'  # Example task name
        self.seq_len = 250  # Sequence length
        self.pred_len = 250  # Prediction length
        self.output_attention = False  # Whether to output attention weights
        self.d_model = 250  # Model dimension
        self.embed = 'timeF'  # Time encoding method
        self.freq = 'h'  # Time frequency
        self.dropout = 0.1  # Dropout rate
        self.factor = 1  # Attention scaling factor
        self.n_heads = 4  # Number of attention heads
        self.e_layers = 3  # Number of encoder layers
        self.d_ff = 256  # Feed-forward network dimension
        self.activation = 'gelu'  # Activation function
        self.enc_in = 63  # Encoder input dimension (example value)



class encoder_low_level(nn.Module):
    def __init__(self, num_channels=63, sequence_length=250, num_subjects=1, num_features=64, num_latents=1024,
                 num_blocks=1):
        super(encoder_low_level, self).__init__()
        self.subject_wise_linear = nn.ModuleList([nn.Linear(sequence_length, 128) for _ in range(num_subjects)])
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))
        self.dropout = nn.Dropout(0.05)

        # CNN upsampler
        self.upsampler = nn.Sequential(
            nn.ConvTranspose2d(8064, 1024, kernel_size=4, stride=2, padding=1),  # (1, 1) -> (2, 2)
            nn.BatchNorm2d(1024),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(1024, 512, kernel_size=4, stride=2, padding=1),  # (2, 2) -> (4, 4)
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(512, 256, kernel_size=4, stride=2, padding=1),  # (4, 4) -> (8, 8)
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1),  # (8, 8) -> (16, 16)
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),  # (16, 16) -> (32, 32)
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1),  # (32, 32) -> (64, 64)
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(32, 16, kernel_size=1, stride=1, padding=0),  # Keep size (64, 64)
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(16, 4, kernel_size=1, stride=1, padding=0),  # Output shape (4, 64, 64)
        )

    def forward(self, x):
        # Apply subject-wise linear layer
        x = self.subject_wise_linear[0](x)  # Output shape: (batchsize, 63, 128)
        # Reshape to match the input size for the upsampler
        x = x.view(x.size(0), 8064, 1, 1)  # Reshape to (batch_size, 8064, 1, 1)
        out = self.upsampler(x)  # Pass through the upsampler
        return out




def train_model(eegmodel,  dataloader, optimizer, device, text_features_all, img_features_all,epoch):
    eegmodel.train()
    total_loss = 0
    mae_loss_fn = nn.L1Loss()

    for batch_idx, (eeg_data, labels, text, text_features, img, img_features) in enumerate(dataloader):
        eeg_data = eeg_data.to(device)
        img_features = img_features.to(device).float()
        labels = labels.to(device)

        optimizer.zero_grad()
        eeg_features = eegmodel(eeg_data[:, :, :250]).float()


        regress_loss = mae_loss_fn(eeg_features, img_features)
        # l2_norm = sum(p.pow(2.0).sum() for p in model.parameters())
        # loss = (regress_loss + ridge_lambda * l2_norm)
        loss = regress_loss
        loss.backward()

        optimizer.step()
        total_loss += loss.item()

    average_loss = total_loss / (batch_idx + 1)
    accuracy = 0
    top5_acc = 0
    return average_loss, accuracy, top5_acc


def evaluate_model(eegmodel, dataloader, device, text_features_all, img_features_all, k,  epoch):
    eegmodel.eval()
    total_loss = 0
    mse_loss_fn = nn.MSELoss()
    mae_loss_fn = nn.L1Loss()
    ridge_lambda = 0.1
    accuracy = 0
    alpha = 0.9
    top5_acc = 0

    with torch.no_grad():
        for batch_idx, (eeg_data, labels, text, text_features, img, img_features) in enumerate(dataloader):
            eeg_data = eeg_data.to(device)
            # eeg_data = eeg_data.permute(0, 2, 1)
            labels = labels.to(device)
            img_features = img_features.to(device).float()
            eeg_features = eegmodel(eeg_data[:, :, :250]).float()
            logit_scale = eegmodel.logit_scale
            regress_loss = mae_loss_fn(eeg_features, img_features)
            # contras_loss = clip_loss(eeg_features.view(eeg_features.size(0), -1), img_features.view(img_features.size(0), -1), logit_scale)
            loss = regress_loss
            total_loss += loss.item()


    torch.cuda.empty_cache()
    average_loss = total_loss / (batch_idx + 1)
    return average_loss, accuracy, top5_acc


def main_train_loop(sub, current_time, eeg_model,  train_dataloader, test_dataloader, optimizer, device,
                    text_features_train_all, text_features_test_all, img_features_train_all, img_features_test_all,
                    config, save_dir, logger=None ):
    # Introduce cosine annealing scheduler
    scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=config.epochs, eta_min=1e-6)
    train_losses, train_accuracies = [], []
    test_losses, test_accuracies = [], []


    best_accuracy = 0.0
    results = []  # List to store results for each epoch

    for epoch in range(config.epochs):
        train_loss, train_accuracy, features_tensor = train_model(eeg_model,  train_dataloader, optimizer,
                                                                  device, text_features_train_all,
                                                                  img_features_train_all, epoch=epoch)
        if (epoch + 1) % 5 == 0:
            file_path = f"{save_dir}/{epoch + 1}.pth"
            torch.save(eeg_model.state_dict(), file_path)

            print(f"model saved in {file_path}!")
        train_losses.append(train_loss)
        train_accuracies.append(train_accuracy)

        # Update learning rate
        scheduler.step()


        test_loss, test_accuracy, top5_acc = evaluate_model(eeg_model,  test_dataloader, device,
                                                            text_features_test_all, img_features_test_all, k=200, epoch=epoch)
        test_losses.append(test_loss)
        test_accuracies.append(test_accuracy)

        # Append results for this epoch
        epoch_results = {
            "epoch": epoch + 1,
            "test_loss": test_loss,
            "test_accuracy": test_accuracy,
        }

        results.append(epoch_results)
        # If the test accuracy in the current epoch is the best, save the model and related information
        if test_accuracy > best_accuracy:
            best_accuracy = test_accuracy


        print(
            f"Epoch {epoch + 1}/{config.epochs} - Train Loss: {train_loss:.4f}, Train Accuracy: {train_accuracy:.4f}, Test Loss: {test_loss:.4f}, Test Accuracy: {test_accuracy:.4f}, Top5 Accuracy: {top5_acc:.4f}")
        torch.cuda.empty_cache()

    return results


def main():
    # Argument parser setup
    parser = argparse.ArgumentParser(description='EEG Model Training Script')
    parser.add_argument('--data_path', type=str, default='/nfs/diskstation/DataStation/public_dataset/Things-EEG-data/Preprocessed_data_250Hz',help='Path to data')

    parser.add_argument('--output_dir', type=str, default='/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/latent_feature/results', help='Directory to save output results')

    parser.add_argument('--lr', type=float, default=1e-4, help='Learning rate')
    parser.add_argument('--epochs', type=int, default=120, help='Number of training epochs')
    parser.add_argument('--batch_size', type=int, default=256, help='Batch size for training')
    parser.add_argument('--insubject', default=True, help='Flag to indicate within-subject training')
    parser.add_argument('--encoder_type', type=str, default='encoder_low_level',help='Encoder type')
    parser.add_argument('--img_encoder', type=str, default='Proj_img', help='Image encoder type')
    parser.add_argument('--logger', default=True, help='Enable logging')
    parser.add_argument('--subjects', nargs='+', default=['sub-02','sub-03','sub-04','sub-05'], help='List of subject IDs')
    args = parser.parse_args()

    device = torch.device('cuda:0')
    data_path = args.data_path
    subjects = args.subjects
    current_time = datetime.datetime.now().strftime("%m-%d_%H-%M")

    for sub in subjects:
        eeg_model = globals()[args.encoder_type]()
        eeg_model.to(device)

        optimizer = torch.optim.AdamW(itertools.chain(eeg_model.parameters()), lr=args.lr)

        train_dataset = EEGDataset(data_path, subjects=[sub], train=True)
        test_dataset = EEGDataset(data_path, subjects=[sub], train=False)


        train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0,drop_last=True)
        test_loader = DataLoader(test_dataset, batch_size=20, shuffle=False, num_workers=0, drop_last=True)

        text_features_train_all = torch.tensor([0]).to(device)
        text_features_test_all = torch.tensor([0]).to(device)
        img_features_train_all = torch.tensor([0]).to(device)
        img_features_test_all = torch.tensor([0]).to(device)

        # Save results to a CSV file
        results_dir = '/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/{}/latent_decoder_results/'.format(sub)
        os.makedirs(results_dir, exist_ok=True)
        results_file = os.path.join(results_dir, f"{args.encoder_type}_{sub}.csv")

        model_dir = '/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/{}/latent_decoder/'.format(sub)
        os.makedirs(model_dir, exist_ok=True)

        results = main_train_loop(sub, current_time, eeg_model, train_loader, test_loader, optimizer, device,
                                  text_features_train_all, text_features_test_all, img_features_train_all,
                                  img_features_test_all,
                                  config=args, save_dir= model_dir,logger=args.logger)



        with open(results_file, 'w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)
            print(f'Results saved to {results_file}')


if __name__ == '__main__':
    main()


"""
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '5'
import sys
sys.path.append('/data1/home/cddu/pythonProject/code/luyizhuo/brain-diffuser/versatile_diffusion')
sys.path.append('/data/home/cddu/pythonProject/code/taming-transformers')
import PIL
from PIL import Image
import numpy as np
import fastl2lir
import torch
import torchvision.transforms as tvtrans
from lib.cfg_helper import model_cfg_bank
from lib.model_zoo import get_model
from lib.model_zoo.ddim_vd import DDIMSampler_VD
import matplotlib.pyplot as plt

import argparse
parser = argparse.ArgumentParser(description='Argument Parser')
parser.add_argument("-diff_str", "--diff_str",help="Diffusion Strength",default=0.75)
args = parser.parse_args()
strength = float(args.diff_str)
device = torch.device('cuda:0')





cfgm_name = 'vd_noema'
sampler = DDIMSampler_VD
pth = '/nfs/diskstation/DataStation/ChangdeDu/LYZ/Versatile_diffusion/vd-four-flow-v1-0-fp16-deprecated.pth'
cfgm = model_cfg_bank()(cfgm_name)
net = get_model()(cfgm)
sd = torch.load(pth, map_location='cpu')
net.load_state_dict(sd, strict=False)

net.clip.to(device)
net.autokl.to(device)

def regularize_image(x):
    BICUBIC = PIL.Image.Resampling.BICUBIC
    if isinstance(x, str):
        x = Image.open(x).resize([512, 512], resample=BICUBIC)
        x = tvtrans.ToTensor()(x)
    elif isinstance(x, PIL.Image.Image):
        x = x.resize([512, 512], resample=BICUBIC)
        x = tvtrans.ToTensor()(x)
    elif isinstance(x, np.ndarray):
        x = PIL.Image.fromarray(x).resize([512, 512], resample=BICUBIC)
        x = tvtrans.ToTensor()(x)
    elif isinstance(x, torch.Tensor):
        pass
    else:
        assert False, 'Unknown image type'

    assert (x.shape[1] == 512) & (x.shape[2] == 512), \
        'Wrong image size'
    return x



img = Image.open('/nfs/diskstation/DataStation/public_dataset/Things-EEG-stimuli/test_images/00001_aircraft_carrier/aircraft_carrier_06s.jpg')
zim = regularize_image(img)
zin = zim*2 - 1
zin = zin.unsqueeze(0).to(device)#.half()

init_latent = net.autokl_encode(zin)

x = net.autokl_decode(init_latent)

x = torch.clamp((x + 1.0) / 2.0, min=0.0, max=1.0).cpu().detach().numpy().squeeze(0)

plt.imshow(x.transpose(1, 2, 0))  # 转换维度为（512, 512, 3）
plt.axis('off')  # 不显示坐标轴
plt.show()








for j in range(10):
    feature = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/latent_feature/val_stim_lattent_z.npy'))[j:j+1,:,:,:].to(device)

    x_samples_ddim = net.autokl_decode(feature)
    x_samples_ddim = torch.clamp((x_samples_ddim + 1.0) / 2.0, min=0.0, max=1.0).cpu().detach().numpy()  # (1,3,256,256)

    image = x_samples_ddim.squeeze(0)  # 去掉第一个维度

    # 将数据从范围[0, 1]转换为[0, 255]并转换为uint8
    # image = (image * 255).astype(np.uint8)

    # 可视化图像
    plt.imshow(image.transpose(1, 2, 0))  # 转换维度为（512, 512, 3）
    plt.axis('off')  # 不显示坐标轴
    plt.show()

"""














