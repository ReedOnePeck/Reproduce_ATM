import os
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
import sys
sys.path.append('/data1/home/cddu/pythonProject/code/luyizhuo/brain-diffuser/versatile_diffusion')
sys.path.append('/data/home/cddu/pythonProject/code/taming-transformers')
import PIL
from PIL import Image
import numpy as np
from torchvision import transforms
import torch
import torchvision.transforms as tvtrans
from lib.cfg_helper import model_cfg_bank
from lib.model_zoo import get_model
from lib.model_zoo.ddim_vd import DDIMSampler_VD
from packages import model_options as MO
from packages import feature_extraction as FE
import matplotlib.pyplot as plt
import torchvision
from torchvision.transforms import InterpolationMode
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from PIL import Image
from torchvision import transforms
from einops import rearrange
from torch import nn
from torch.optim import lr_scheduler
from torch.optim import Adam
from torchvision.utils import make_grid
from torch.autograd import Variable

import argparse
parser = argparse.ArgumentParser(description='Argument Parser')
parser.add_argument("-diff_str", "--diff_str",help="Diffusion Strength",default=0.75)
args = parser.parse_args()
strength = float(args.diff_str)
device = torch.device('cuda:0')




def regularize_image(x):
    BICUBIC = PIL.Image.Resampling.BICUBIC
    if isinstance(x, str):
        x = Image.open(x).resize([512, 512], resample=BICUBIC)
        x = tvtrans.ToTensor()(x)
    elif isinstance(x, PIL.Image.Image):
        x = x.resize([512, 512], resample=BICUBIC)
        x = tvtrans.ToTensor()(x)
    elif isinstance(x, np.ndarray):
        x = PIL.Image.fromarray(x).resize([512, 512], resample=BICUBIC)
        x = tvtrans.ToTensor()(x)
    elif isinstance(x, torch.Tensor):
        pass
    else:
        assert False, 'Unknown image type'

    assert (x.shape[1] == 512) & (x.shape[2] == 512), \
        'Wrong image size'
    return x

j = 0
feature1 = torch.load('/nfs/diskstation/DataStation/public_dataset/Things-EEG-data/test_image_latent_512.pt')['image_latent'][j:j+1,:,:,:].to(device)
feature = torch.randn_like(feature1).to(device)

cfgm_name = 'vd_noema'
sampler = DDIMSampler_VD
pth = '/nfs/diskstation/DataStation/ChangdeDu/LYZ/Versatile_diffusion/vd-four-flow-v1-0-fp16-deprecated.pth'
cfgm = model_cfg_bank()(cfgm_name)
net = get_model()(cfgm)
sd = torch.load(pth, map_location='cpu')
net.load_state_dict(sd, strict=False)

net.clip.to(device)
net.autokl.to(device)
sampler = sampler(net)
sampler.model.model.diffusion_model.device='cuda:0'
sampler.model.model.diffusion_model.cuda(0)
#sampler.model.model.diffusion_model.half().cuda(0)
#net.autokl.half()
torch.manual_seed(0)



n_samples = 1
ddim_steps = 50
ddim_eta = 0
scale = 7.5
xtype = 'image'
ctype = 'prompt'

zim = Image.open('/nfs/diskstation/DataStation/ChangdeDu/LYZ/Versatile_diffusion/Try_VD/1269_real.png')

zim = regularize_image(zim)
zin = zim*2 - 1
zin = zin.unsqueeze(0).to(device)#.half()

init_latent = feature
sampler.make_schedule(ddim_num_steps=ddim_steps, ddim_eta=ddim_eta, verbose=False)
assert 0. <= strength <= 1., 'can only work with strength in [0.0, 1.0]'
t_enc = int(strength * ddim_steps)
device = 'cuda:0'
z_enc = sampler.stochastic_encode(init_latent, torch.tensor([t_enc]).to(device))

dummy = ''
utx = net.clip_encode_text(dummy)
utx = utx.to(device)#.half()

text = 'A picture of aircraft carrier.'
ctx = net.clip_encode_text(text)
ctx = ctx.to(device)#.half()

dummy = torch.zeros((1, 3, 224, 224)).cuda(0)
uim = net.clip_encode_vision(dummy)
uim = uim.to(device)#.half()

img = Image.open('/nfs/diskstation/DataStation/ChangdeDu/LYZ/Versatile_diffusion/Try_VD/1269_real.png')
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # 调整图像大小为 224x224
    transforms.ToTensor(),          # 将图像转换为张量
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # 标准化
])

img_tensor = transform(img)
img_tensor = img_tensor.unsqueeze(0).cuda(0)
cim = net.clip_encode_vision(img_tensor)
cim = cim.to(device)#.half()


z_enc = z_enc.to(device)



sampler.model.model.diffusion_model.device='cuda:0'
sampler.model.model.diffusion_model.cuda(0)#.half()
# mixing = 0.4

z = sampler.decode_dc(
    x_latent=z_enc,
    first_conditioning=[uim, cim],
    second_conditioning=[utx, ctx],
    t_start=t_enc,
    unconditional_guidance_scale=scale,
    xtype='image',
    first_ctype='vision',
    second_ctype='prompt',
    mixed_ratio=  0)    #(1 - mixing), )   mixed_ratio表示的是CLIP图像特征占的比例，Ozclik用的0.6，Paul用的1

z = z.to(device)#.half()
x = net.autokl_decode(z)

x = torch.clamp((x + 1.0) / 2.0, min=0.0, max=1.0).cpu().detach().numpy().squeeze(0)


plt.imshow(x.transpose(1, 2, 0))  # 转换维度为（512, 512, 3）
plt.axis('off')  # 不显示坐标轴
plt.show()



