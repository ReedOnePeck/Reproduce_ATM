import os
os.environ['CUDA_VISIBLE_DEVICES'] = '4'
import torch
import numpy as np
import random

SEED = 42
if SEED is not None:
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    random.seed(SEED)
from pytorch_lightning import seed_everything

seed = 42
seed_everything(seed)

from omegaconf import OmegaConf
from torch.autograd import Variable
import PIL
from einops import rearrange
from torchvision.utils import make_grid

from torch.optim import lr_scheduler
from torch.optim import Adam
from torch import autocast
from tqdm import tqdm
from ldm.util import instantiate_from_config
from ldm.models.diffusion.dpm_solver import DPMSolverSampler
from ldm.models.diffusion.ddim import DDIMSampler
from PIL import Image
from torchvision import transforms
import torchvision
from torchvision.transforms import InterpolationMode
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torch import nn

loss_fn = nn.MSELoss()

from packages import model_options as MO
from packages import feature_extraction as FE

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
import pickle


device = torch.device('cuda:0')

print("引用无报错")



# ----------------------------------------------------------------------------------------------------------------------------------------------------------------
# 一、模型准备
# （1）CLIP
model_string = 'ViT-B/32_clip'
model_option = MO.get_model_options()[model_string]
image_transforms_CLIP = MO.get_recommended_transforms(model_string)
model_name = model_option['model_name']
train_type = model_option['train_type']


def retrieve_clip_model(model_name):
    import clip;
    model, _ = clip.load(model_name, device='cpu')
    return model.visual


model_CLIP = eval(model_option['call'])
model_CLIP = model_CLIP.eval()
model_CLIP = model_CLIP.to(device)



def CLIP_of_generated(generated_frames, model=model_CLIP):
    class TensorDataset(Dataset):
        # TensorDataset继承Dataset, 重载了__init__, __getitem__, __len__
        def __init__(self, data_tensor, image_transforms=None):
            self.data_tensor = data_tensor
            self.transforms = image_transforms

        def __getitem__(self, index):
            img = self.data_tensor[index]
            if self.transforms:
                img = self.transforms(img)
            return img  # .to(torch.float16)

        def __len__(self):
            return self.data_tensor.size(0)

    transform_for_CLIP = torchvision.transforms.Compose([
        transforms.Resize((224, 224), interpolation=InterpolationMode.BICUBIC, antialias=False),
        transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
    ])

    stimulus_loader = DataLoader(TensorDataset(generated_frames, transform_for_CLIP), batch_size=32)

    target_layers = ['Linear-2', 'Linear-4', 'Linear-6', 'Linear-8']

    feature_maps = FE.get_all_feature_maps(model, stimulus_loader, layers_to_retain=target_layers,
                                           remove_duplicates=False, numpy=False)
    for feature_map in feature_maps.keys():
        feature_maps[feature_map] = feature_maps[feature_map].to(device)

    return feature_maps


def MSE_CLIP(target, generated, weight):
    MSE = 0
    for feature_map in generated.keys():
        if feature_map != 'VisionTransformer-1':
            MSEi = (1 - weight) * loss_fn(target[feature_map], generated[feature_map])
            MSE = MSE + MSEi
        else:
            MSEi = 1. - torch.cosine_similarity(target[feature_map], generated[feature_map])
            MSE = MSE + 0.1 * weight * MSEi
    return MSE


# (2)Stable diffusion
def load_model_from_config(config, ckpt, verbose=False):
    print(f"Loading model from {ckpt}")
    pl_sd = torch.load(ckpt, map_location="cuda:0")
    sd = pl_sd["state_dict"]
    model = instantiate_from_config(config.model)
    m, u = model.load_state_dict(sd, strict=False)
    if len(m) > 0 and verbose:
        print("missing keys:")
        print(m)
    if len(u) > 0 and verbose:
        print("unexpected keys:")
        print(u)

    model.cuda()
    model.eval()
    return model


def get_model():
    config = OmegaConf.load("/nfs/diskstation/DataStation/ChangdeDu/LYZ/stable-diffusion/configs/v1-inference.yaml")
    model = load_model_from_config(config,
                                   "/nfs/diskstation/DataStation/ChangdeDu/LYZ/stable-diffusion/checkpoints/sd-v1-4.ckpt")
    return model


model = get_model()
device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
model = model.to(device)
sampler = DDIMSampler(model)
sampler.make_schedule(ddim_num_steps=50, ddim_eta=0.0, verbose=False)



text_feature = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/text_feature/val_caps_LDM_feature_len_15.npy').astype(np.float32)).to(device)
labels = np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/recons_results/sub1/test_labels.npy')

latent_feature = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/latent_feature/pred_sub1_latent.npy').astype(np.float32)).to(device)

linear2 = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/recons_results/sub1/structure_feature_linear2.npy').astype(np.float32)).to(device)
linear4 = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/recons_results/sub1/structure_feature_linear4.npy').astype(np.float32)).to(device)
linear6 = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/recons_results/sub1/structure_feature_linear6.npy').astype(np.float32)).to(device)
linear8 = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/recons_results/sub1/structure_feature_linear8.npy').astype(np.float32)).to(device)
target_layers = ['Linear-2', 'Linear-4', 'Linear-6', 'Linear-8']
target_layers_feature = [linear2,linear4,linear6,linear8]

for idx in tqdm(range(100)):
    dic = dict()
    for j in range(4):
        layer_name = target_layers[j]
        reverse_pred = target_layers_feature[j][idx:idx+1,:]
        dic[layer_name] = reverse_pred
    CLIP_target = dic

    with model.ema_scope():
        uc = model.get_learned_conditioning(1 * [""])
    z = latent_feature[idx:idx+1,:,:,:]
    c = text_feature[int(labels[idx]):int(labels[idx])+1]
    z = Variable(z, requires_grad=True)
    c = Variable(c, requires_grad=True)
    params = [c, z]

    picture_save_path = '/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/recons_results/sub1/recons_with_ours/picture_{}'.format(idx+1)
    if not os.path.exists(picture_save_path):
        os.makedirs(picture_save_path)
    # Reconstruction
    iterations = 60
    LR = 0.002

    optimizer = Adam(params, lr=LR)
    scheduler = lr_scheduler.ExponentialLR(optimizer, gamma=0.999)
    for iter in range(iterations):
        scheduler.step()

        z_enc = sampler.stochastic_encode(z, torch.tensor([37] * 1).to(device))
        samples = sampler.decode(z_enc, c, 35, unconditional_guidance_scale=5.0, unconditional_conditioning=uc, )
        x_samples_ddim = model.decode_first_stage(samples)
        x_samples_ddim = torch.clamp((x_samples_ddim + 1.0) / 2.0, min=0.0, max=1.0)

        optimizer.zero_grad()
        CLIP_generated = CLIP_of_generated(generated_frames=x_samples_ddim)
        loss = MSE_CLIP(target = CLIP_target, generated = CLIP_generated, weight = 0)

        loss.backward(retain_graph=False)
        optimizer.step()
        lr = optimizer.state_dict()['param_groups'][0]['lr']

        if iter % 2 == 0:
            # visualize reconstructions
            grid = rearrange(x_samples_ddim, 'b c h w -> (b) c h w')
            grid = make_grid(grid, nrow=1)
            grid = 255. * rearrange(grid, 'c h w -> h w c').cpu().detach().numpy()
            Image.fromarray(grid.astype(np.uint8)).save('%s/rec_iter_%03d.png' % (picture_save_path, iter))
            print(
                '===============================================================> Iter: {:03d} LR: {:.4f} Train loss: {:.4f}'.format(
                    iter, lr, loss.item()))

        del loss, CLIP_generated, x_samples_ddim, samples
        torch.cuda.empty_cache()



























