import numpy as np


file1 = np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/Linear-4_train1.npy')
file2 = np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/Linear-4_train2.npy')
saved_features = np.concatenate([file1,file2], axis = 0)
print('')