import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os
import torch
from ldm.util import instantiate_from_config
from omegaconf import OmegaConf
from PIL import Image
import PIL
from tqdm import tqdm

os.environ['CUDA_VISIBLE_DEVICES'] = '2'
device = torch.device('cuda:0')

data_path = '/nfs/diskstation/DataStation/public_dataset/Things-EEG-data/Preprocessed_data_250Hz'
img_directory_training = '/nfs/diskstation/DataStation/public_dataset/Things-EEG-stimuli/training_images'
img_directory_test = '/nfs/diskstation/DataStation/public_dataset/Things-EEG-stimuli/test_images'


def load_model_from_config(config, ckpt, verbose=False):
    print(f"Loading model from {ckpt}")
    pl_sd = torch.load(ckpt, map_location="cuda:0")
    sd = pl_sd["state_dict"]
    model = instantiate_from_config(config.model)
    m, u = model.load_state_dict(sd, strict=False)
    if len(m) > 0 and verbose:
        print("missing keys:")
        print(m)
    if len(u) > 0 and verbose:
        print("unexpected keys:")
        print(u)

    model.cuda()
    model.eval()
    return model

def get_model():
    config = OmegaConf.load("/nfs/diskstation/DataStation/ChangdeDu/LYZ/stable-diffusion/configs/v1-inference.yaml")
    model = load_model_from_config(config, "/nfs/diskstation/DataStation/ChangdeDu/LYZ/stable-diffusion/checkpoints/sd-v1-4.ckpt")
    return model

model = get_model().to(device)


def load_data(train=True, classes=None,pictures=None,subjects=['sub-01'],exclude_subject=None):
    data_list = []
    label_list = []
    texts = []
    images = []

    if train:
        directory = img_directory_training
    else:
        directory = img_directory_test
    # 获取该路径下的所有目录
    dirnames = [d for d in os.listdir(directory) if os.path.isdir(os.path.join(directory, d))]
    dirnames.sort()

    if classes is not None:
        dirnames = [dirnames[i] for i in classes]

    for dir in dirnames:
        # 尝试找到第一个'_'的位置
        try:
            idx = dir.index('_')
            description = dir[idx + 1:]  # 从第一个'_'之后取得所有内容
        except ValueError:
            print(f"Skipped: {dir} due to no '_' found.")
            continue

        new_description = f"This picture is {description}"
        texts.append(new_description)

    if train:
        img_directory = img_directory_training  # 请将其替换为你的新地址
    else:
        img_directory = img_directory_test

    all_folders = [d for d in os.listdir(img_directory) if os.path.isdir(os.path.join(img_directory, d))]
    all_folders.sort()  # 保证文件夹的顺序

    if classes is not None and pictures is not None:
        images = []  # 初始化images列表
        for i in range(len(classes)):
            class_idx = classes[i]
            pic_idx = pictures[i]
            if class_idx < len(all_folders):
                folder = all_folders[class_idx]
                folder_path = os.path.join(img_directory, folder)
                all_images = [img for img in os.listdir(folder_path) if
                              img.lower().endswith(('.png', '.jpg', '.jpeg'))]
                all_images.sort()
                if pic_idx < len(all_images):
                    images.append(os.path.join(folder_path, all_images[pic_idx]))
    elif classes is not None and pictures is None:
        images = []  # 初始化images列表
        for i in range(len(classes)):
            class_idx = classes[i]
            if class_idx < len(all_folders):
                folder = all_folders[class_idx]
                folder_path = os.path.join(img_directory, folder)
                all_images = [img for img in os.listdir(folder_path) if
                              img.lower().endswith(('.png', '.jpg', '.jpeg'))]
                all_images.sort()
                images.extend(os.path.join(folder_path, img) for img in all_images)
    elif classes is None:
        images = []  # 初始化images列表
        for folder in all_folders:
            folder_path = os.path.join(img_directory, folder)
            all_images = [img for img in os.listdir(folder_path) if img.lower().endswith(('.png', '.jpg', '.jpeg'))]
            all_images.sort()
            images.extend(os.path.join(folder_path, img) for img in all_images)
    else:
        # 处理其他情况，比如 self.classes 和 self.pictures 长度不匹配
        print("Error")

    print("self.subjects", subjects)

    for subject in subjects:
        if train:
            file_name = 'preprocessed_eeg_training.npy'

            file_path = os.path.join(data_path, subject, file_name)
            data = np.load(file_path, allow_pickle=True)

            preprocessed_eeg_data = torch.from_numpy(data['preprocessed_eeg_data']).float().detach()
            times = torch.from_numpy(data['times']).detach()[50:]
            ch_names = data['ch_names']  # 保留为 Python 列表，或者进行适当的编码

            n_classes = 1654  # 每个类包含10张图片
            samples_per_class = 10  # 一个类有十个数据

            if classes is not None and pictures is not None:
                for c, p in zip(classes, pictures):
                    start_index = c * 1 + p
                    if start_index < len(preprocessed_eeg_data):  # 确保索引不超出范围
                        preprocessed_eeg_data_class = preprocessed_eeg_data[start_index: start_index + 1]  # 只选择一条数据
                        labels = torch.full((1,), c, dtype=torch.long).detach()  # 添加类标签
                        data_list.append(preprocessed_eeg_data_class)
                        label_list.append(labels)  # 将标签添加到标签列表中

            elif classes is not None and pictures is None:
                for c in classes:
                    start_index = c * samples_per_class
                    preprocessed_eeg_data_class = preprocessed_eeg_data[
                                                  start_index: start_index + samples_per_class]
                    labels = torch.full((samples_per_class,), c, dtype=torch.long).detach()  # 添加类标签
                    data_list.append(preprocessed_eeg_data_class)
                    label_list.append(labels)

            else:
                for i in range(n_classes):
                    start_index = i * samples_per_class
                    # if self.exclude_subject==None:
                    #     preprocessed_eeg_data_class = preprocessed_eeg_data[start_index: start_index+samples_per_class]
                    # else:
                    preprocessed_eeg_data_class = preprocessed_eeg_data[
                                                  start_index: start_index + samples_per_class]
                    # print("preprocessed_eeg_data_class", preprocessed_eeg_data_class.shape)
                    # preprocessed_eeg_data_class = torch.mean(preprocessed_eeg_data_class, 1)
                    # preprocessed_eeg_data_class = torch.mean(preprocessed_eeg_data_class, 0)
                    # print("preprocessed_eeg_data_class", preprocessed_eeg_data_class.shape)
                    labels = torch.full((samples_per_class,), i, dtype=torch.long).detach()  # 添加类标签
                    data_list.append(preprocessed_eeg_data_class)
                    label_list.append(labels)


        else:
            if subject == exclude_subject or exclude_subject == None:  # 跳过被排除的被试                    :  # 跳过被排除的被试
                file_name = 'preprocessed_eeg_test.npy'
                file_path = os.path.join(data_path, subject, file_name)
                data = np.load(file_path, allow_pickle=True)
                preprocessed_eeg_data = torch.from_numpy(data['preprocessed_eeg_data']).float().detach()
                times = torch.from_numpy(data['times']).detach()[50:]
                ch_names = data['ch_names']  # 保留为 Python 列表，或者进行适当的编码
                n_classes = 200  # Each class contains 1 images

                samples_per_class = 1  # 一个类有1个数据

                for i in range(n_classes):
                    if classes is not None and i not in classes:  # If we've defined specific classes and the current class is not in the list, skip
                        continue
                    start_index = i * samples_per_class  # Update start_index for each class
                    preprocessed_eeg_data_class = preprocessed_eeg_data[start_index:start_index + samples_per_class]
                    # print("preprocessed_eeg_data_class", preprocessed_eeg_data_class.shape)
                    labels = torch.full((samples_per_class * 80,), i, dtype=torch.long).detach()  # Add class labels
                    # preprocessed_eeg_data_class = torch.mean(preprocessed_eeg_data_class.squeeze(0), 0)
                    # print("preprocessed_eeg_data_class", preprocessed_eeg_data_class.shape)
                    data_list.append(preprocessed_eeg_data_class)
                    label_list.append(labels)  # Add labels to the label list
            else:
                continue
    # datalist: (subjects * classes) * (10 * 4 * 17 * 100)
    # data_tensor: (subjects * classes * 10 * 4) * 17 * 100
    # data_list = np.mean(data_list, )
    # print("data_list", len(data_list))
    if train:
        # print("data_list", *data_list[0].shape[1:])
        data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape[2:])
        # data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape[1:])
        # data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape)
        # print("label_tensor", label_tensor.shape)
        print("data_tensor", data_tensor.shape)
    else:
        data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape[2:])
        # label_tensor = torch.cat(label_list, dim=0)
        # print("label_tensor", label_tensor.shape)
        # data_tensor = torch.cat(data_list, dim=0).view(-1, *data_list[0].shape[2:])
    # print("data_tensor", data_tensor.shape)
    # label_list: (subjects * classes) * 10
    # label_tensor: (subjects * classes * 10)
    # print("label_tensor = torch.cat(label_list, dim=0)")
    # print(label_list)
    label_tensor = torch.cat(label_list, dim=0)
    # label_tensor = torch.cat(label_list, dim=0)
    # print(label_tensor[:300])
    if train:
        # label_tensor: (subjects * classes * 10 * 4)
        label_tensor = label_tensor.repeat_interleave(4)
        if classes is not None:
            unique_values = list(label_tensor.numpy())
            lis = []
            for i in unique_values:
                if i not in lis:
                    lis.append(i)
            unique_values = torch.tensor(lis)
            mapping = {val.item(): index for index, val in enumerate(unique_values)}
            label_tensor = torch.tensor([mapping[val.item()] for val in label_tensor], dtype=torch.long)

    else:
        # label_tensor = label_tensor.repeat_interleave(80)
        # if self.classes is not None:
        #     unique_values = torch.unique(label_tensor, sorted=False)

        #     mapping = {val.item(): index for index, val in enumerate(torch.flip(unique_values, [0]))}
        #     label_tensor = torch.tensor([mapping[val.item()] for val in label_tensor], dtype=torch.long)
        pass

    return data_tensor, label_tensor, texts, images

def load_img(stim,picture_idx):
    image = stim[picture_idx:picture_idx+1, :, :].squeeze()
    image = (255 * image).astype(np.uint8)
    image = Image.fromarray(image.transpose(1, 2, 0))
    image.convert('RGB')
    image = image.resize((512, 512))

    w, h = image.size
    w, h = map(lambda x: x - x % 32, (w, h))  # resize to integer multiple of 32
    image = image.resize((w, h), resample=PIL.Image.LANCZOS)
    image = np.array(image).astype(np.float32) / 255.0
    image = image[None].transpose(0, 3, 1, 2)
    image = torch.from_numpy(image)
    return 2.*image - 1.


def latent_feature_extract(imgs,idx):
    stim = np.array(imgs)
    VAE = []
    for i in tqdm(range(stim.shape[0])):
        img = load_img(stim, i).to(device)
        z = model.get_first_stage_encoding(model.encode_first_stage(img)).cpu().detach().numpy().squeeze()
        VAE.append(z)
    np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/latent_feature/{}_stim_lattent_z.npy'.format(idx), VAE)
    return


def textfeature_extract(text_list,idx):
    caps = []
    for text in tqdm(text_list):
        cap = model.get_learned_conditioning([text]).cpu().detach().numpy().squeeze()
        caps.append(cap)
    np.save(
        '/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/text_feature/{}_caps_LDM_feature_len_15.npy'.format(idx), caps)
    return



#'This picture is aardvark'

_, _, train_text, train_images = load_data(train=True, classes=None,pictures=None,subjects=['sub-01'],exclude_subject=None)
train_imgs = torch.stack([torch.tensor(np.array(Image.open(img).convert("RGB")) / 255.) for img in train_images]).permute(0, 3, 1, 2).to(torch.float32)
#latent_feature_extract(train_imgs,'trn')
textfeature_extract(train_text,'trn')
print('训练集提取完毕')


_, _, val_text, val_images = load_data(train=False, classes=None,pictures=None,subjects=['sub-01'],exclude_subject=None)
val_imgs = torch.stack([torch.tensor(np.array(Image.open(img).convert("RGB")) / 255.) for img in val_images]).permute(0, 3, 1, 2).to(torch.float32)
#latent_feature_extract(val_imgs,'val')
textfeature_extract(val_text,'val')
print('测试集提取完毕')


