import os
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
import torch
device = torch.device('cuda:0')
import matplotlib.pyplot as plt
from einops.layers.torch import Rearrange
from torch.utils.data import DataLoader, Dataset
import random
import csv
from torch import Tensor
import itertools
import re
import numpy as np
import argparse
from torch import nn
from torch.optim import AdamW
import math
import pickle
import h5py
import clip
from tqdm import tqdm
from torch.optim import lr_scheduler


from EEG_recons.subject_layers.Transformer_EncDec import Encoder, EncoderLayer
from EEG_recons.subject_layers.SelfAttention_Family import FullAttention, AttentionLayer
from EEG_recons.subject_layers.Embed import DataEmbedding
from EEG_recons.loss import ClipLoss
from EEG_recons.util import wandb_logger


def zscore_eeg_data(eeg_data):
    """
    对EEG数据进行z-score标准化。

    参数:
    eeg_data : numpy.ndarray
        形状为(A, B, C)的numpy数组，其中A是数据个数，B是通道数，C是时间点数。

    返回:
    numpy.ndarray
        标准化后的EEG数据。
    """
    A, B, C = eeg_data.shape
    zscored_data = np.zeros_like(eeg_data)

    for b in range(B):
        # 计算每个通道的均值和标准差
        mu = np.mean(eeg_data[:, b, :], axis=1, keepdims=True)
        sigma = np.std(eeg_data[:, b, :], axis=1, keepdims=True)

        # 应用z-score标准化
        zscored_data[:, b, :] = (eeg_data[:, b, :] - mu) / sigma

    return zscored_data


class Config:
    def __init__(self):
        self.task_name = 'classification'  # Example task name
        self.seq_len = 201  # Sequence length
        self.pred_len = 250  # Prediction length
        self.output_attention = False  # Whether to output attention weights
        self.d_model = 250  # Model dimension
        self.embed = 'timeF'  # Time encoding method
        self.freq = 'h'  # Time frequency
        self.dropout = 0.25  # Dropout rate
        self.factor = 1  # Attention scaling factor
        self.n_heads = 4  # Number of attention heads
        self.e_layers = 1  # Number of encoder layers
        self.d_ff = 256  # Dimension of the feedforward network
        self.activation = 'gelu'  # Activation function
        self.enc_in = 271  # Encoder input dimension (example value)


class iTransformer(nn.Module):
    def __init__(self, configs):
        super(iTransformer, self).__init__()
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.output_attention = configs.output_attention
        # Embedding
        self.enc_embedding = DataEmbedding(configs.seq_len, configs.d_model, configs.embed, configs.freq,
                                           configs.dropout, joint_train=False, num_subjects=1)
        # Encoder
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(False, configs.factor, attention_dropout=configs.dropout,
                                      output_attention=configs.output_attention),
                        configs.d_model, configs.n_heads
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation
                ) for l in range(configs.e_layers)
            ],
            norm_layer=torch.nn.LayerNorm(configs.d_model)
        )

    def forward(self, x_enc, x_mark_enc, subject_ids=None):
        # Embedding
        enc_out = self.enc_embedding(x_enc, x_mark_enc, subject_ids)
        enc_out, attns = self.encoder(enc_out, attn_mask=None)
        #enc_out = enc_out[:, :271, :]
        return enc_out


class PatchEmbedding(nn.Module):
    def __init__(self, emb_size=40):
        super().__init__()
        # Revised from ShallowNet
        self.tsconv = nn.Sequential(
            nn.Conv2d(1, 40, (1, 25), stride=(1, 1)),
            nn.AvgPool2d((1, 51), (1, 5)),
            nn.BatchNorm2d(40),
            nn.ELU(),
            nn.Conv2d(40, 40, (271, 1), stride=(1, 1)),
            nn.BatchNorm2d(40),
            nn.ELU(),
            nn.Dropout(0.5),
        )

        self.projection = nn.Sequential(
            nn.Conv2d(40, emb_size, (1, 1), stride=(1, 1)),
            Rearrange('b e (h) (w) -> b (h w) e'),
        )

    def forward(self, x: Tensor) -> Tensor:
        x = x.unsqueeze(1)

        x = self.tsconv(x)

        x = self.projection(x)
        return x


class ResidualAdd(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        res = x
        x = self.fn(x, **kwargs)
        x += res
        return x


class FlattenHead(nn.Sequential):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        x = x.contiguous().view(x.size(0), -1)
        return x


class Enc_eeg(nn.Sequential):
    def __init__(self, emb_size=40, **kwargs):
        super().__init__(
            PatchEmbedding(emb_size),
            FlattenHead()
        )


class Proj_eeg(nn.Sequential):
    def __init__(self, embedding_dim=2880, proj_dim=512, drop_proj=0.5):
        super().__init__(
            nn.Linear(embedding_dim, proj_dim),
            ResidualAdd(nn.Sequential(
                nn.GELU(),
                nn.Linear(proj_dim, proj_dim),
                nn.Dropout(drop_proj),
            )),
            nn.LayerNorm(proj_dim),
        )


class ATMS(nn.Module):
    def __init__(self, num_channels=271, sequence_length=201, num_subjects=2, num_features=64, num_latents=1024,
                 num_blocks=1):
        super(ATMS, self).__init__()
        default_config = Config()
        self.encoder = iTransformer(default_config)
        self.enc_eeg = Enc_eeg()
        self.proj_eeg = Proj_eeg()
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))
        self.loss_func = ClipLoss()

    def forward(self, x, subject_ids):
        x = self.encoder(x, None, subject_ids)
        eeg_embedding = self.enc_eeg(x)

        out = self.proj_eeg(eeg_embedding)
        return out

Subs = [1,2,3,4]

for sub in tqdm(Subs):
    weight_dtype = torch.float32
    val_MEG_path = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy/sub-0{}/preprocessed_meg_zs_test.pkl'.format(sub)

    with open(val_MEG_path, 'rb') as val_file:
        val_data = pickle.load(val_file)
    val_MEG_data = torch.tensor(zscore_eeg_data(np.mean(np.squeeze(val_data['meg_data']), axis=1)),
                                dtype=torch.float32).to(device)  # (200, 1, 12, 271, 201)

    batch_size = val_MEG_data.shape[0]
    subject_ids = torch.full((batch_size,), 1, dtype=torch.long).to(device)

    # 对c的解码
    semantic_decoder = ATMS()
    semantic_decoder.load_state_dict(torch.load(
        '/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/sub{}/semantic_decoder/MEG_semantic_decoder_90.pth'.format(sub),
        map_location=torch.device('cuda:0')))
    semantic_decoder.to(device)
    semantic_decoder.eval()

    # test_set_CLIP_emb_trivial_test = np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_for_img_recons/sub01/stimuli/trivial_test/contrastive/trivial_test_img_embeddings_CLIP_512.npy')
    img_features_all = np.load(
        '/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Test_clip_img_embeddings.npy')

    meg_emb = semantic_decoder(val_MEG_data, subject_ids).cpu().detach().numpy()

    all_labels = set(range(200))
    selected_classes = list(all_labels)

    Labels = []
    for j, label in enumerate(all_labels):
        meg_feature = meg_emb[j:j + 1, :]
        logits_img = meg_feature @ img_features_all.T
        predicted_label = selected_classes[np.argmax(logits_img).item()]
        Labels.append(predicted_label)

    np.save(f'/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/sub{sub}/Lidongyang_test_labels.npy',Labels)
