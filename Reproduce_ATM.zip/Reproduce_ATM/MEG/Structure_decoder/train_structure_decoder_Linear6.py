import os
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
import torch
device = torch.device('cuda:0')
import matplotlib.pyplot as plt
from einops.layers.torch import Rearrange
from torch.utils.data import DataLoader, Dataset
from torch import Tensor
import numpy as np
import argparse
from torch import nn
import pickle
from tqdm import tqdm
from torch.optim import lr_scheduler
from sklearn.metrics.pairwise import cosine_similarity

from EEG_recons.subject_layers.Transformer_EncDec import Encoder, EncoderLayer
from EEG_recons.subject_layers.SelfAttention_Family import FullAttention, AttentionLayer
from EEG_recons.subject_layers.Embed import DataEmbedding
from EEG_recons.loss import ClipLoss



def top_k_accuracy(data, queries, labels, k=1):
    correct = 0
    total = len(queries)

    for idx, query in enumerate(queries):
        # 计算查询和数据集中每个点的余弦相似度
        sim = cosine_similarity([query], data).flatten()
        # 根据相似度排序，找出top-k的索引
        top_k_indices = sim.argsort()[-k:][::-1]

        # 检查正确的索引是否在top-k中
        if labels[idx] in top_k_indices:
            correct += 1
            #print("idx",idx)
            #print("top_k_indices",top_k_indices)

    return correct / total

def zscore_eeg_data(eeg_data):
    """
    对EEG数据进行z-score标准化。

    参数:
    eeg_data : numpy.ndarray
        形状为(A, B, C)的numpy数组，其中A是数据个数，B是通道数，C是时间点数。

    返回:
    numpy.ndarray
        标准化后的EEG数据。
    """
    A, B, C = eeg_data.shape
    zscored_data = np.zeros_like(eeg_data)

    for b in range(B):
        # 计算每个通道的均值和标准差
        mu = np.mean(eeg_data[:, b, :], axis=1, keepdims=True)
        sigma = np.std(eeg_data[:, b, :], axis=1, keepdims=True)

        # 应用z-score标准化
        zscored_data[:, b, :] = (eeg_data[:, b, :] - mu) / sigma

    return zscored_data


class Config:
    def __init__(self):
        self.task_name = 'classification'  # Example task name
        self.seq_len = 201  # Sequence length
        self.pred_len = 250  # Prediction length
        self.output_attention = False  # Whether to output attention weights
        self.d_model = 250  # Model dimension
        self.embed = 'timeF'  # Time encoding method
        self.freq = 'h'  # Time frequency
        self.dropout = 0.25  # Dropout rate
        self.factor = 1  # Attention scaling factor
        self.n_heads = 4  # Number of attention heads
        self.e_layers = 1  # Number of encoder layers
        self.d_ff = 256  # Dimension of the feedforward network
        self.activation = 'gelu'  # Activation function
        self.enc_in = 271  # Encoder input dimension (example value)


class iTransformer(nn.Module):
    def __init__(self, configs):
        super(iTransformer, self).__init__()
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.output_attention = configs.output_attention
        # Embedding
        self.enc_embedding = DataEmbedding(configs.seq_len, configs.d_model, configs.embed, configs.freq,
                                           configs.dropout, joint_train=False, num_subjects=1)
        # Encoder
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(False, configs.factor, attention_dropout=configs.dropout,
                                      output_attention=configs.output_attention),
                        configs.d_model, configs.n_heads
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation
                ) for l in range(configs.e_layers)
            ],
            norm_layer=torch.nn.LayerNorm(configs.d_model)
        )

    def forward(self, x_enc, x_mark_enc, subject_ids=None):
        # Embedding
        enc_out = self.enc_embedding(x_enc, x_mark_enc, subject_ids)
        enc_out, attns = self.encoder(enc_out, attn_mask=None)
        #enc_out = enc_out[:, :271, :]
        return enc_out


class PatchEmbedding(nn.Module):
    def __init__(self, emb_size=40):
        super().__init__()
        # Revised from ShallowNet
        self.tsconv = nn.Sequential(
            nn.Conv2d(1, 40, (1, 25), stride=(1, 1)),
            nn.AvgPool2d((1, 51), (1, 5)),
            nn.BatchNorm2d(40),
            nn.ELU(),
            nn.Conv2d(40, 40, (271, 1), stride=(1, 1)),
            nn.BatchNorm2d(40),
            nn.ELU(),
            nn.Dropout(0.5),
        )

        self.projection = nn.Sequential(
            nn.Conv2d(40, emb_size, (1, 1), stride=(1, 1)),
            Rearrange('b e (h) (w) -> b (h w) e'),
        )

    def forward(self, x: Tensor) -> Tensor:
        x = x.unsqueeze(1)

        x = self.tsconv(x)

        x = self.projection(x)
        return x


class ResidualAdd(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        res = x
        x = self.fn(x, **kwargs)
        x += res
        return x


class FlattenHead(nn.Sequential):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        x = x.contiguous().view(x.size(0), -1)
        return x


class Enc_eeg(nn.Sequential):
    def __init__(self, emb_size=40, **kwargs):
        super().__init__(
            PatchEmbedding(emb_size),
            FlattenHead()
        )


class Proj_eeg(nn.Sequential):
    def __init__(self, embedding_dim=2880, proj_dim=512, drop_proj=0.5):
        super().__init__(
            nn.Linear(embedding_dim, proj_dim),
            ResidualAdd(nn.Sequential(
                nn.GELU(),
                nn.Linear(proj_dim, proj_dim),
                nn.Dropout(drop_proj),
            )),
            nn.LayerNorm(proj_dim),
        )


class ATMS(nn.Module):
    def __init__(self, num_channels=271, sequence_length=201, num_subjects=2, num_features=64, num_latents=1024,
                 num_blocks=1):
        super(ATMS, self).__init__()
        default_config = Config()
        self.encoder = iTransformer(default_config)
        self.enc_eeg = Enc_eeg()
        self.proj_eeg = Proj_eeg(embedding_dim=2880, proj_dim=38400, drop_proj=0.5)
        #self.proj_out = Proj_eeg(embedding_dim=2880,proj_dim=38400, drop_proj=0)
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))
        self.loss_func = ClipLoss()

    def forward(self, x, subject_ids):
        x = self.encoder(x, None, subject_ids)
        eeg_embedding = self.enc_eeg(x)

        out = self.proj_eeg(eeg_embedding)
        #out = self.proj_out(out1)
        return out




subject_ID = '1'

weight_dtype = torch.float32
train_MEG_path = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy/sub-0{}/preprocessed_meg_training.pkl'.format(subject_ID)
val_MEG_path = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy/sub-0{}/preprocessed_meg_zs_test.pkl'.format(subject_ID)

with open(train_MEG_path, 'rb') as train_file:
    train_data = pickle.load(train_file)


train_MEG_data = torch.tensor(zscore_eeg_data(np.squeeze(train_data['meg_data']).reshape(-1, 271, 201)), dtype=torch.float32).to(device)    #(1654, 12, 1, 271, 201)     (class,  sample,  trial,   chanel,  time_points)


with open(val_MEG_path, 'rb') as val_file:
    val_data = pickle.load(val_file)
val_MEG_data = torch.tensor(zscore_eeg_data(np.mean(np.squeeze(val_data['meg_data']), axis=1)), dtype=torch.float32).to(device)         #(200, 1, 12, 271, 201)


CLIP_img1 = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/Linear-6_train1.npy'), dtype=torch.float32)
CLIP_img2 = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/Linear-6_train2.npy'), dtype=torch.float32)
CLIP_img3 = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/Linear-6_train3.npy'), dtype=torch.float32)
CLIP_img4 = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/Linear-6_train4.npy'), dtype=torch.float32)

train_tgt_CLIP_img = torch.concat([CLIP_img1, CLIP_img2, CLIP_img3, CLIP_img4], dim=0).to(device)
print(train_tgt_CLIP_img.shape)

val_tgt_CLIP_img = torch.tensor(np.load('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/Linear-6_test.npy'), dtype=torch.float32).to(device)


class Train_dataset(Dataset):
    def __init__(self, sliding_window_start):
        #MEG
        self.trn_MEG = train_MEG_data#train_MEG_data[:,:,self.start:self.start+450]
        #Img
        self.trn_tgt_CLIP_picture = train_tgt_CLIP_img


        self.size = train_MEG_data.shape[0]


    def __len__(self):
        data_size = self.size
        return data_size

    def __getitem__(self, item):
        trn_MEG = self.trn_MEG[item, :, :]

        trn_tgt_CLIP_picture = self.trn_tgt_CLIP_picture[item, :]


        return trn_MEG, 0, trn_tgt_CLIP_picture

class Val_dataset(Dataset):
    def __init__(self, sliding_window_start):
        self.test_src = val_MEG_data#val_MEG_data[:,:,self.start:self.start+450]
        self.test_tgt_CLIP_picture = val_tgt_CLIP_img

        self.size = val_MEG_data.shape[0]

    def __len__(self):
        data_size = self.size
        return data_size

    def __getitem__(self, item):
        test_src = self.test_src[item, :, :]

        test_tgt_CLIP_picture = self.test_tgt_CLIP_picture[item, :]

        return test_src, 0, test_tgt_CLIP_picture


# ----------------------------------------------------------Train------------------------------------------------------------------

class NoamOpt:
    "Optim wrapper that implements rate."

    def __init__(self, model_size, factor, warmup, optimizer):
        self.optimizer = optimizer
        self._step = 0
        self.warmup = warmup
        self.factor = factor
        self.model_size = model_size
        self._rate = 0.01

    def step(self):
        "Update parameters and rate"
        self._step += 1
        rate = self.rate()
        for p in self.optimizer.param_groups:
            p['lr'] = rate
        self._rate = rate
        self.optimizer.step()

    def rate(self, step=None):
        "Implement `lrate` above"
        if step is None:
            step = self._step
        return self.factor * \
               (self.model_size ** (-0.5) *
                min(step ** (-0.5), step * self.warmup ** (-1.5)))


def contrastive_loss(logits):
    return nn.functional.cross_entropy(logits, torch.arange(len(logits), device=logits.device))


def clip_loss(similarity):
    caption_loss = contrastive_loss(similarity)
    image_loss = contrastive_loss(similarity.t())
    return (caption_loss + image_loss) / 2.0


class Contrastive_loss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, logits_per_unit):
        loss = clip_loss(logits_per_unit)
        return loss


class SimpleLossCompute:
    def __init__(self, criterion1, criterion2, k1, k2,  opt=None):
        self.criterion1 = criterion1
        self.criterion2 = criterion2
        self.k1 = k1
        self.k2 = k2
        self.opt = opt

    def __call__(self, mode, epoch=None,y_pred=None, regularization=None, y_pred_mid=None, logits_per_fMRI_t=None,
                 logits_per_fMRI_i=None, y_tgt=None, y_CLIP_t=None, y_CLIP_i=None, norm=None):
        if mode == 'train':
            loss_pre = self.criterion2(y_pred_mid, y_CLIP_i) / norm
            loss_fMRI_text = 0
            loss_fMRI_img = self.criterion1(logits_per_fMRI_i) / norm
            #loss_proj = self.criterion2(y_pred, y_tgt) / norm
            loss_contrast = 0.5 * (loss_fMRI_text + loss_fMRI_img)


            print("loss_pre:",loss_pre)
            print("loss_contrast:", loss_contrast)
            #print("loss_proj:", loss_proj)


            #loss = 0.2 * loss_pre + self.k1 * loss_contrast + self.k2 * loss_proj
            loss =  1.5 * loss_pre + self.k1 * loss_contrast
            #print("train_loss:", loss)

            return loss

        else:
            loss_pre = self.criterion2(y_pred_mid, y_CLIP_i) / norm
            loss_fMRI_text = 0
            loss_fMRI_img = self.criterion1(logits_per_fMRI_i) / norm
            #loss_proj = self.criterion2(y_pred, y_tgt) / norm
            loss_contrast = 0.5 * (loss_fMRI_text + loss_fMRI_img)


            #loss = 0.2 * loss_pre + self.k1 * loss_contrast + self.k2 * loss_proj
            loss =  1.5 * loss_pre + self.k1 * loss_contrast

            return  loss.data.item() * norm


def run_epoch(mode, data_iter, model, loss_compute, norm=1, epoch=None, opt=None, scheduler=None):
    train_loss = []
    val_loss = []
    val_top5_acc = []
    for i, batch in tqdm(enumerate(data_iter)):
        if mode == 'train':
            trn_src, trn_tgt_CLIP_text, trn_tgt_CLIP_picture = batch
            batch_size = trn_src.size(0)
            subject_ids = torch.full((batch_size,), 1, dtype=torch.long)

            x = model.forward(trn_src, subject_ids)
            logit_scale = model.logit_scale.exp()
            fMRI_embeds = x / x.norm(p=2, dim=-1, keepdim=True)
            image_embeds = trn_tgt_CLIP_picture / trn_tgt_CLIP_picture.norm(p=2, dim=-1, keepdim=True)

            logits_per_fMRI_t = 0
            logits_per_fMRI_i = torch.matmul(fMRI_embeds, image_embeds.t()) * logit_scale


            loss = loss_compute(mode=mode, epoch=epoch, y_pred_mid=x,y_CLIP_t=0,y_CLIP_i=trn_tgt_CLIP_picture.squeeze(1),
                                logits_per_fMRI_t=logits_per_fMRI_t,logits_per_fMRI_i=logits_per_fMRI_i, norm=norm)

            opt.zero_grad()
            loss.backward()
            opt.step()
            train_loss.append(loss.data.item() )

        if mode == 'val':
            val_src, val_tgt_CLIP_text, val_tgt_CLIP_picture = batch
            batch_size = val_src.size(0)
            subject_ids = torch.full((batch_size,), 1, dtype=torch.long)

            x = model.forward(val_src, subject_ids)
            logit_scale = model.logit_scale.exp()
            fMRI_embeds = x / x.norm(p=2, dim=-1, keepdim=True)
            image_embeds = val_tgt_CLIP_picture / val_tgt_CLIP_picture.norm(p=2, dim=-1, keepdim=True)

            logits_per_fMRI_t = 0
            logits_per_fMRI_i = torch.matmul(fMRI_embeds, image_embeds.t()) * logit_scale


            v_loss = loss_compute(mode=mode, epoch=epoch, y_pred_mid=x,y_CLIP_t=0,y_CLIP_i=val_tgt_CLIP_picture.squeeze(1),
                                  logits_per_fMRI_t=logits_per_fMRI_t,logits_per_fMRI_i=logits_per_fMRI_i, norm=norm)
            val_loss.append(v_loss)


            data_novel = val_tgt_CLIP_picture.cpu().detach().numpy()
            queries = x.cpu().detach().numpy()
            labels_novel = np.arange(data_novel.shape[0])
            top_5_acc_novel = top_k_accuracy(data_novel, queries, labels_novel, k=5)

            if i <3:
                print(f"Top-5 Accuracy_novel: {top_5_acc_novel:.4f}")
                val_top5_acc.append(top_5_acc_novel)



    if scheduler is not None:
        scheduler.step()
        #print('学习率是{}'.format(opt.state_dict()['param_groups'][0]['lr']))


    return train_loss, val_loss, val_top5_acc


def main():
    parser = argparse.ArgumentParser(description='MEG_Semantic_decoding')
    parser.add_argument('--model_dir', help='model saved path', default='/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/sub{}/structure/Linear6/',type=str)
    parser.add_argument('--figure_dir', help='figure saved path', default='/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/sub{}/structure/Linear6/pictures/',type=str)
    parser.add_argument('--batch_size', help='batch size of dnn training', default=64, type=int)
    parser.add_argument('--epoch', help='epoch', default=70, type=int)
    parser.add_argument('--subj_ID', help='subj_ID', default=1, type=int)
    parser.add_argument('--n_blocks', help='n_mlp_blocks', default=1, type=float)
    parser.add_argument('--k1', help='ratio of loss_CLIP', default=1, type=float)
    parser.add_argument('--k2', help='ratio of loss_raw', default=1, type=float)
    parser.add_argument('--lr', help='learning rate', default=2e-5, type=float)
    parser.add_argument('--warm_up', help='warm_up', default=10, type=float)
    parser.add_argument('--sliding_window', help='sliding_window_start', default=0, type=float)
    args = parser.parse_args()

    if not os.path.exists(args.model_dir.format(subject_ID)):
        os.makedirs(args.model_dir.format(subject_ID))

    if not os.path.exists(args.figure_dir.format(subject_ID)):
        os.makedirs(args.figure_dir.format(subject_ID))


    criterion1 = Contrastive_loss()
    criterion2 = nn.MSELoss()
    model = ATMS().to(device)
    model_opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = lr_scheduler.ExponentialLR(model_opt, gamma=0.999)

    trainset = Train_dataset(sliding_window_start=args.sliding_window)
    validation_set = Val_dataset(sliding_window_start = args.sliding_window)

    Train_loss = []
    Val_loss = []
    Top5_acc = []

    for epoch in tqdm(range(args.epoch + 1)):
        model.train()
        train_data = DataLoader(trainset, batch_size=args.batch_size, shuffle=True)
        train_loss, _, _ = run_epoch(mode='train', data_iter=train_data, model=model,
                                     loss_compute=SimpleLossCompute(
                                            criterion1=criterion1, criterion2=criterion2,k1=args.k1, k2=args.k2 ),
                                      norm=1, epoch=epoch,opt=model_opt, scheduler=scheduler)

        Train_loss.append(np.mean(train_loss))
        if epoch in [5, 10, 20,30,40,50,60,70,80,90,100,120,140,160,180,200]:  #120
            torch.save(model.state_dict(), os.path.join(args.model_dir.format(subject_ID), 'MEG_semantic_decoder_{}.pth'.format(epoch)))



        model.eval()
        val_data = DataLoader(validation_set, batch_size=100, shuffle=False)
        _, val_loss, top5_acc = run_epoch(mode='val', data_iter=val_data, model=model,
                                      loss_compute=SimpleLossCompute(
                                          criterion1=criterion1, criterion2=criterion2,k1=args.k1, k2=args.k2),
                                      norm=1, epoch=epoch)
        Val_loss.append(np.mean(val_loss))
        Top5_acc.append(np.mean(top5_acc))



        if epoch in [50,70,100,150,200]:
            plt.figure()
            epochs = range(len(Train_loss))
            plt.plot(epochs, Train_loss, 'red', label='Train_loss')
            plt.plot(epochs, Val_loss, 'green', label='Val_loss')

            plt.title('Loss-epoch{}'.format(epoch))
            plt.legend(loc='upper right')

            plt.savefig(args.figure_dir.format(subject_ID)+'Loss-epoch{}.png'.format(epoch))
            plt.show()


            plt.figure()
            plt.plot(epochs, Top5_acc, 'orange', label='Val_accuracy')
            plt.title('Top5-Accuracy-epoch{}'.format(epoch))
            plt.legend(loc='upper right')
            plt.savefig(args.figure_dir.format(subject_ID) + 'Top5-Accuracy-epoch{}.png'.format(epoch))
            plt.show()


if __name__ == "__main__":
    main()
    print('')











