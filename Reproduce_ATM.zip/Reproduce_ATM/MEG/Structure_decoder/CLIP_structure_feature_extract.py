import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os
from sklearn.preprocessing import StandardScaler
import torch
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
import torchvision
from torchvision import transforms
from packages import model_options as MO
from packages import feature_extraction_detach as FE
from PIL import Image
from tqdm import tqdm

os.environ['CUDA_VISIBLE_DEVICES'] = '2'
device = torch.device('cuda:0')



def CLIP_extraction(data, target_layer):
    model_string = 'ViT-B/32_clip'
    model_option = MO.get_model_options()[model_string]
    image_transforms = MO.get_recommended_transforms(model_string)
    model_name = model_option['model_name']
    train_type = model_option['train_type']

    def retrieve_clip_model(model_name):
        import clip;
        model, _ = clip.load(model_name, device='cpu')
        return model.visual

    model = eval(model_option['call'])
    model = model.eval()
    model = model.to(device)

    transform_for_CLIP = torchvision.transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.Normalize(mean=(0.485, 0.456, 0.406),
        std=(0.229, 0.224, 0.225))
    ])

    class TensorDataset(Dataset):
        def __init__(self, data_tensor, image_transforms=None):
            self.data_tensor = data_tensor
            self.transforms = image_transforms

        def __getitem__(self, index):
            img = self.data_tensor[index]
            if self.transforms:
                img = self.transforms(img)
            return img

        def __len__(self):
            return self.data_tensor.size(0)

    #data_tensor = torch.tensor(np.load(filepath))#[8000:,:,:]
    data_tensor = data
    stimulus_loader = DataLoader(TensorDataset(data_tensor, transform_for_CLIP), batch_size=128)
    target_layers = target_layer
    feature_maps = FE.get_all_feature_maps(model, stimulus_loader, layers_to_retain=target_layers,
                                           remove_duplicates=False, numpy=True)



    feature = feature_maps[target_layers]
    print(target_layers, feature_maps[target_layers].shape)
    return feature

    del feature_maps
    torch.cuda.empty_cache()


"""
#Test
test_root = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/images_set/test_images/'
test_imgs = []

test_img_paths = []
for folder_name in os.listdir(test_root):
    test_img_paths.append(os.path.join(test_root, folder_name))

All_test_img_names = []
for folder_path in test_img_paths:
    for file_name in os.listdir(folder_path):
        All_test_img_names.append(os.path.join(folder_path, file_name))


test_imgs = torch.stack([torch.tensor(np.array(Image.open(img).convert("RGB").resize((500, 500))) / 255.) for img in All_test_img_names]).permute(0, 3, 1, 2).to(torch.float32)


target_layers = ['Linear-10', 'Linear-12']  #'Linear-2', 'Linear-4', 'Linear-6', 'Linear-8',

for target_layer in target_layers:
    test_feature = CLIP_extraction(test_imgs, target_layer)
    np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_test.npy'.format(target_layer),test_feature)
    print('测试集的{}特征提取完毕'.format(target_layer))
"""








train_root = '/nfs/diskstation/DataStation/public_dataset/Things_MEG/images_set/training_images/'
train_img_paths = []
for folder_name in os.listdir(train_root):
    train_img_paths.append(os.path.join(train_root, folder_name))

All_train_img_names = []                #19848
for folder_path in train_img_paths:
    for file_name in os.listdir(folder_path):
        All_train_img_names.append(os.path.join(folder_path, file_name))

imgs = torch.stack([torch.tensor(np.array(Image.open(img).convert("RGB").resize((500, 500))) / 255.) for img in tqdm(All_train_img_names)]).permute(0, 3, 1, 2).to(torch.float32)
#/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_layers_feature

target_layer = 'Linear-2'

image_inputs1 = imgs[:10000,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[10000:20000,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train2.npy'.format(target_layer),train_feature2)

print('训练集的{}特征提取完毕'.format(target_layer))




target_layer = 'Linear-4'

image_inputs1 = imgs[:8270,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[8270:8270*2,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train2.npy'.format(target_layer),train_feature2)

image_inputs3 = imgs[8270*2:,:,:,:]
train_feature3 = CLIP_extraction(image_inputs3, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train3.npy'.format(target_layer),train_feature3)
print('训练集的{}特征提取完毕'.format(target_layer))


target_layer = 'Linear-6'

image_inputs1 = imgs[:5520,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[5520:5520+5520,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train2.npy'.format(target_layer),train_feature2)

image_inputs3 = imgs[5520+5520:5520*3,:,:,:]
train_feature3 = CLIP_extraction(image_inputs3, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train3.npy'.format(target_layer),train_feature3)

image_inputs4 = imgs[5520*3:,:,:,:]
train_feature4 = CLIP_extraction(image_inputs4, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train4.npy'.format(target_layer),train_feature4)

print('训练集的{}特征提取完毕'.format(target_layer))


target_layer = 'Linear-8'

image_inputs1 = imgs[:4135,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[4135:4135+4135,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train2.npy'.format(target_layer),train_feature2)

image_inputs3 = imgs[4135+4135:4135+4135+4135,:,:,:]
train_feature3 = CLIP_extraction(image_inputs3, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train3.npy'.format(target_layer),train_feature3)

image_inputs4 = imgs[4135+4135+4135:4135*4,:,:,:]
train_feature4 = CLIP_extraction(image_inputs4, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train4.npy'.format(target_layer),train_feature4)

image_inputs5 = imgs[4135*4:,:,:,:]
train_feature5 = CLIP_extraction(image_inputs5, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train5.npy'.format(target_layer),train_feature5)
print('训练集的{}特征提取完毕'.format(target_layer))


target_layer = 'Linear-10'

image_inputs1 = imgs[:3308,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[3308:3308+3308,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train2.npy'.format(target_layer),train_feature2)

image_inputs3 = imgs[3308+3308:3308+3308+3308,:,:,:]
train_feature3 = CLIP_extraction(image_inputs3, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train3.npy'.format(target_layer),train_feature3)

image_inputs4 = imgs[3308+3308+3308:3308+3308+3308+3308,:,:,:]
train_feature4 = CLIP_extraction(image_inputs4, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train4.npy'.format(target_layer),train_feature4)

image_inputs5 = imgs[3308+3308+3308+3308:3308*5,:,:,:]
train_feature5 = CLIP_extraction(image_inputs5, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train5.npy'.format(target_layer),train_feature5)

image_inputs6 = imgs[3308*5:,:,:,:]
train_feature6 = CLIP_extraction(image_inputs6, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train6.npy'.format(target_layer),train_feature6)

print('训练集的{}特征提取完毕'.format(target_layer))




target_layer = 'Linear-12'

image_inputs1 = imgs[:3308,:,:,:]
train_feature1 = CLIP_extraction(image_inputs1, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train1.npy'.format(target_layer),train_feature1)

image_inputs2 = imgs[3308:3308+3308,:,:,:]
train_feature2 = CLIP_extraction(image_inputs2, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train2.npy'.format(target_layer),train_feature2)

image_inputs3 = imgs[3308+3308:3308+3308+3308,:,:,:]
train_feature3 = CLIP_extraction(image_inputs3, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train3.npy'.format(target_layer),train_feature3)

image_inputs4 = imgs[3308+3308+3308:3308+3308+3308+3308,:,:,:]
train_feature4 = CLIP_extraction(image_inputs4, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train4.npy'.format(target_layer),train_feature4)

image_inputs5 = imgs[3308+3308+3308+3308:3308*5,:,:,:]
train_feature5 = CLIP_extraction(image_inputs5, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train5.npy'.format(target_layer),train_feature5)

image_inputs6 = imgs[3308*5:,:,:,:]
train_feature6 = CLIP_extraction(image_inputs6, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/MEG_recons/structure_features/{}_train6.npy'.format(target_layer),train_feature6)

print('训练集的{}特征提取完毕'.format(target_layer))









"""

_, _, _, test_images = load_data(train=False, classes=None,pictures=None,subjects=['sub-01'],exclude_subject=None)

#for target_layer in target_layers:
image_inputs = torch.stack([torch.tensor(np.array(Image.open(img).convert("RGB")) / 255.) for img in test_images]).permute(0, 3, 1, 2).to(torch.float32)
test_feature = CLIP_extraction(image_inputs, target_layer)
np.save('/nfs/diskstation/DataStation/ChangdeDu/LYZ/MindDiffuser-V2-results/EEG-recons/structure_feature/{}_test.npy'.format(target_layer),test_feature)
print('测试集的{}特征提取完毕'.format(target_layer))
"""














