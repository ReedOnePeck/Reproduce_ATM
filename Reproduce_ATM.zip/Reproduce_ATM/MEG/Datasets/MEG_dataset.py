import pickle

path = "/nfs/diskstation/DataStation/public_dataset/Things_MEG/sub1/preprocessed_npy/sub-01/preprocessed_meg_training.pkl"


with open(path, 'rb') as file:
    data = pickle.load(file)



meg_data = data['meg_data']  #(1654, 12, 1, 271, 201)
ch_names = data['ch_names']
times = data['times']
print('')