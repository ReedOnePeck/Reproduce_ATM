import numpy as np
import h5py

"""
a = np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Train_clip_img_embeddings_1.npy')
b = np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Train_clip_img_embeddings_2.npy')
c = np.load('/nfs/diskstation/DataStation/public_dataset/Things_MEG_features/CLIP_img_512/Train_clip_img_embeddings_3.npy')

data = np.concatenate([a,b,c], axis=0)
print('')
"""




# 打开.h5文件
with h5py.File('/nfs/diskstation/DataStation/public_dataset/Things_MEG/Train_captions.h5', 'r') as file:
    # 打印文件中的所有数据集的键名
    print("Keys in the file:", list(file.keys()))

    # 读取某个特定数据集
    dataset = file['Train_captions'][:]
    print("Dataset shape:", dataset.shape)
    print("Dataset content:", dataset)
